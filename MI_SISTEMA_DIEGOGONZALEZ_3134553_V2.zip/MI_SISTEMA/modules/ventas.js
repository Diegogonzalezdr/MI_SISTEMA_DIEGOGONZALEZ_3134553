/**
 * ventas.js — Módulo de Ventas (versión simple y funcional)
 */

// ============================================================
//  VISTA
// ============================================================
window.viewVentas = function() {
  const hoy = new Date().toISOString().substring(0, 10);
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Ventas</div>
        <div class="page-subtitle">Registro de ventas diarias</div>
      </div>
      <button class="btn btn-primary" onclick="mostrarResumen()">📊 Ver resumen del día</button>
    </div>

    <!-- FORMULARIO -->
    <div class="table-container" style="max-width:580px; margin-bottom:24px">
      <div class="table-header"><span class="table-title">NUEVA VENTA</span></div>
      <div style="padding:20px; display:flex; flex-direction:column; gap:14px">

        <div class="form-group" style="margin:0;position:relative">
          <label class="form-label">Producto *</label>
          <input class="form-input" type="text" id="v-buscar-producto"
            placeholder="Buscar por nombre o código..."
            autocomplete="off" />
          <input type="hidden" id="v-producto-id" />
          <div id="v-resultados" style="display:none;position:absolute;top:100%;left:0;right:0;
               background:var(--bg-elevated);border:1px solid var(--accent);border-top:none;
               border-radius:0 0 4px 4px;z-index:200;max-height:220px;overflow-y:auto"></div>
          <div id="v-producto-seleccionado" style="display:none;margin-top:6px;padding:8px 12px;
               background:var(--accent-dim);border:1px solid var(--accent);border-radius:4px;
               font-size:12px;font-family:var(--font-mono);color:var(--accent);
               display:none;justify-content:space-between;align-items:center">
            <span id="v-producto-label"></span>
            <button onclick="limpiarProductoSeleccionado()"
              style="background:none;border:none;color:var(--accent);cursor:pointer;font-size:16px;padding:0 4px">×</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px">
          <div class="form-group" style="margin:0">
            <label class="form-label">Cantidad *</label>
            <input class="form-input" type="number" id="v-cantidad" min="1" value="1">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Precio unitario *</label>
            <input class="form-input" type="number" id="v-precio" min="0" step="0.01" placeholder="0.00">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Fecha *</label>
            <input class="form-input" type="date" id="v-fecha" value="${hoy}">
          </div>
        </div>

        <div style="background:var(--bg-base); border:1px solid var(--border); border-radius:4px;
                    padding:12px 16px; display:flex; justify-content:space-between; align-items:center">
          <span style="font-family:var(--font-mono); font-size:12px; color:var(--text-muted)">SUBTOTAL</span>
          <span style="font-family:var(--font-mono); font-size:20px; color:var(--accent)" id="v-preview">$0.00</span>
        </div>

        <div id="v-msg" style="display:none" class="alert"></div>

        <button class="btn btn-primary" style="padding:11px; font-size:13px" onclick="registrarVenta()">
          ✓ Registrar Venta
        </button>
      </div>
    </div>

    <!-- TABLA DE VENTAS -->
    <div class="table-container">
      <div class="table-header">
        <span class="table-title">VENTAS REGISTRADAS</span>
        <span id="v-total-hoy" style="font-family:var(--font-mono); font-size:12px; color:var(--accent)"></span>
      </div>
      <table>
        <thead>
          <tr>
            <th>N°</th>
            <th>Fecha</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Unit.</th>
            <th>Total</th>
            <th>Estado</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody id="v-tbody"></tbody>
      </table>
    </div>

    <!-- MODAL RESUMEN -->
    <div id="modal-resumen" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.75);
         z-index:500; align-items:center; justify-content:center">
      <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:6px;
                  width:560px; max-width:95vw; max-height:85vh; overflow-y:auto">
        <div style="display:flex; justify-content:space-between; align-items:center;
                    padding:16px 20px; border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono); font-weight:600">📊 Resumen del día</span>
          <button onclick="document.getElementById('modal-resumen').style.display='none'"
            style="background:none; border:none; color:var(--text-muted); font-size:20px; cursor:pointer">×</button>
        </div>
        <div id="modal-resumen-body" style="padding:20px"></div>
        <div style="padding:14px 20px; border-top:1px solid var(--border); display:flex; justify-content:flex-end; gap:8px">
          <button class="btn btn-outline" onclick="document.getElementById('modal-resumen').style.display='none'">Cerrar</button>
          <button class="btn btn-primary" onclick="imprimirResumen()">🖨 Imprimir</button>
        </div>
      </div>
    </div>
  `;
};

// ============================================================
//  CONTROLADOR — se llama después de inyectar el HTML
// ============================================================
window.initVentas = function() {
  // Buscador de productos
  const inputBuscar = document.getElementById('v-buscar-producto');

  inputBuscar.addEventListener('input', function() {
    const q = this.value.trim().toLowerCase();
    const res = document.getElementById('v-resultados');
    if (q.length < 1) { res.style.display = 'none'; return; }

    const productos = DB.Productos.getAll().filter(p =>
      p.nombre.toLowerCase().includes(q) || p.codigo.toLowerCase().includes(q)
    );

    if (!productos.length) {
      res.innerHTML = '<div style="padding:10px 14px;font-size:12px;color:var(--text-muted)">Sin resultados</div>';
      res.style.display = 'block';
      return;
    }

    res.innerHTML = productos.map(p => `
      <div class="v-resultado-item" data-id="${p.id}" data-precio="${p.precio_venta}"
           data-nombre="${p.nombre}" data-codigo="${p.codigo}" data-stock="${p.stock}"
           style="padding:10px 14px;cursor:pointer;border-bottom:1px solid var(--border);
                  display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:13px;color:var(--text-primary)">${p.nombre}</div>
          <div style="font-size:10px;font-family:var(--font-mono);color:var(--text-muted)">
            ${p.codigo} · Stock: ${p.stock}
          </div>
        </div>
        <div style="font-family:var(--font-mono);font-size:13px;color:var(--accent)">
          $${parseFloat(p.precio_venta).toFixed(2)}
        </div>
      </div>
    `).join('');

    res.style.display = 'block';

    res.querySelectorAll('.v-resultado-item').forEach(el => {
      el.addEventListener('mouseenter', () => el.style.background = 'var(--bg-hover)');
      el.addEventListener('mouseleave', () => el.style.background = '');
      el.addEventListener('click', () => {
        seleccionarProducto(el.dataset.id, el.dataset.nombre, el.dataset.codigo,
                            el.dataset.precio, el.dataset.stock);
      });
    });
  });

  // Cierra resultados al hacer click fuera
  document.addEventListener('click', function(e) {
    if (!e.target.closest('#v-buscar-producto') && !e.target.closest('#v-resultados')) {
      const res = document.getElementById('v-resultados');
      if (res) res.style.display = 'none';
    }
  });

  // Preview en tiempo real
  document.getElementById('v-cantidad').addEventListener('input', actualizarPreview);
  document.getElementById('v-precio').addEventListener('input', actualizarPreview);

  // Carga tabla de ventas
  renderTablaVentas();
};

function seleccionarProducto(id, nombre, codigo, precio, stock) {
  document.getElementById('v-producto-id').value = id;
  document.getElementById('v-buscar-producto').value = '';
  document.getElementById('v-resultados').style.display = 'none';
  document.getElementById('v-precio').value = parseFloat(precio).toFixed(2);

  const label = document.getElementById('v-producto-label');
  label.textContent = nombre + ' (' + codigo + ') · Stock: ' + stock;

  const sel = document.getElementById('v-producto-seleccionado');
  sel.style.display = 'flex';

  actualizarPreview();
  document.getElementById('v-cantidad').focus();
}

window.limpiarProductoSeleccionado = function() {
  document.getElementById('v-producto-id').value = '';
  document.getElementById('v-precio').value = '';
  document.getElementById('v-producto-seleccionado').style.display = 'none';
  document.getElementById('v-buscar-producto').value = '';
  document.getElementById('v-preview').textContent = '$0.00';
  document.getElementById('v-buscar-producto').focus();
};

function recargarBuscador() {
  // Limpia selección si el producto ya no existe o cambió stock
  const id = document.getElementById('v-producto-id').value;
  if (id) {
    const prod = DB.Productos.getById(parseInt(id));
    if (prod) {
      const label = document.getElementById('v-producto-label');
      label.textContent = prod.nombre + ' (' + prod.codigo + ') · Stock: ' + prod.stock;
    }
  }
}

function actualizarPreview() {
  const cant   = parseFloat(document.getElementById('v-cantidad').value) || 0;
  const precio = parseFloat(document.getElementById('v-precio').value)   || 0;
  document.getElementById('v-preview').textContent = '$' + (cant * precio).toFixed(2);
}

// ============================================================
//  REGISTRAR VENTA
// ============================================================
window.registrarVenta = function() {
  const msgEl    = document.getElementById('v-msg');
  msgEl.style.display = 'none';
  msgEl.className = 'alert';

  const productoId = parseInt(document.getElementById('v-producto-id').value);
  const cantidad   = parseInt(document.getElementById('v-cantidad').value);
  const precio     = parseFloat(document.getElementById('v-precio').value);
  const fecha      = document.getElementById('v-fecha').value;

  // Validaciones
  if (!productoId)          { mostrarMsg('error', 'Busca y selecciona un producto.'); return; }
  if (!cantidad || cantidad < 1) { mostrarMsg('error', 'La cantidad debe ser mayor a 0.'); return; }
  if (!precio || precio <= 0)    { mostrarMsg('error', 'El precio debe ser mayor a 0.'); return; }
  if (!fecha)                    { mostrarMsg('error', 'Selecciona una fecha.'); return; }

  // Verificar stock
  const prod = DB.Productos.getById(productoId);
  if (!prod) { mostrarMsg('error', 'Producto no encontrado.'); return; }
  if (prod.stock < cantidad) {
    mostrarMsg('error', 'Stock insuficiente. Disponible: ' + prod.stock + ' unidades.');
    return;
  }

  // Generar número de venta
  const ultimo = DB.dbGet("SELECT numero FROM ventas ORDER BY id DESC LIMIT 1");
  const num    = ultimo ? parseInt(ultimo.numero.replace('V-', '')) + 1 : 1;
  const numero = 'V-' + String(num).padStart(4, '0');
  const subtotal = cantidad * precio;
  const fechaHora = fecha + ' ' + new Date().toTimeString().substring(0, 8);

  // Insertar venta
  DB.dbRun(
    "INSERT INTO ventas (numero, subtotal, impuesto, total, estado, creado_en) VALUES (?,?,0,?,'completada',?)",
    [numero, subtotal, subtotal, fechaHora]
  );

  // Obtener ID real recién insertado
  const ventaRow = DB.dbGet("SELECT id FROM ventas WHERE numero = ?", [numero]);
  const ventaId  = ventaRow ? ventaRow.id : null;

  if (!ventaId) { mostrarMsg('error', 'Error al obtener ID de venta.'); return; }

  // Insertar detalle
  DB.dbRun(
    "INSERT INTO ventas_detalle (venta_id, producto_id, cantidad, precio_unit, subtotal) VALUES (?,?,?,?,?)",
    [ventaId, productoId, cantidad, precio, subtotal]
  );

  // Descontar stock
  const stockAntes   = prod.stock;
  const stockDespues = stockAntes - cantidad;
  DB.dbRun("UPDATE productos SET stock = ? WHERE id = ?", [stockDespues, productoId]);

  // Registrar movimiento
  DB.dbRun(
    "INSERT INTO movimientos (producto_id, tipo, cantidad, stock_antes, stock_despues, referencia, nota, usuario_id) VALUES (?,'salida',?,?,?,?,'Venta registrada',1)",
    [productoId, -cantidad, stockAntes, stockDespues, numero]
  );

  // Alerta stock bajo
  if (stockDespues <= prod.stock_minimo) {
    DB.Notificaciones.create('alerta', 'Stock bajo',
      '"' + prod.nombre + '" tiene solo ' + stockDespues + ' unidades.');
    updateNotifBadge();
  }

  DB.saveDB();

  // Feedback
  mostrarMsg('success', '✓ Venta ' + numero + ' registrada — Total: $' + subtotal.toFixed(2) + ' · Stock restante: ' + stockDespues);

  // Resetea form
  
  document.getElementById('v-cantidad').value = '1';
  document.getElementById('v-precio').value   = '';
  document.getElementById('v-preview').textContent = '$0.00';

  // Primero renderiza la tabla, luego limpia el formulario
  renderTablaVentas();

  // Limpia selección de producto
  document.getElementById('v-producto-id').value = '';
  document.getElementById('v-producto-seleccionado').style.display = 'none';
  document.getElementById('v-producto-label').textContent = '';
  document.getElementById('v-buscar-producto').value = '';

  setTimeout(() => { msgEl.style.display = 'none'; }, 5000);
};

function mostrarMsg(tipo, texto) {
  const el = document.getElementById('v-msg');
  el.className = 'alert alert-' + (tipo === 'error' ? 'error' : 'success');
  el.textContent = texto;
  el.style.display = 'block';
}

// ============================================================
//  TABLA DE VENTAS
// ============================================================
function renderTablaVentas() {
  const ventas = DB.dbQuery(`
    SELECT v.id, v.numero, v.creado_en, v.estado, v.total,
           vd.cantidad, vd.precio_unit, vd.subtotal,
           p.nombre AS producto_nombre
    FROM ventas v
    JOIN ventas_detalle vd ON vd.venta_id = v.id
    JOIN productos p ON p.id = vd.producto_id
    ORDER BY v.creado_en DESC
    LIMIT 100
  `);

  const tbody = document.getElementById('v-tbody');
  if (!tbody) return;

  if (!ventas.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:28px">Sin ventas registradas aún</td></tr>';
  } else {
    tbody.innerHTML = ventas.map(v => `
      <tr style="${v.estado === 'anulada' ? 'opacity:0.4' : ''}">
        <td style="font-family:var(--font-mono);font-size:11px">${v.numero}</td>
        <td style="font-family:var(--font-mono);font-size:11px">${(v.creado_en || '').substring(0,10)}</td>
        <td>${v.producto_nombre}</td>
        <td style="font-family:var(--font-mono);text-align:center">${v.cantidad}</td>
        <td style="font-family:var(--font-mono)">$${parseFloat(v.precio_unit).toFixed(2)}</td>
        <td style="font-family:var(--font-mono);color:var(--accent)">$${parseFloat(v.subtotal).toFixed(2)}</td>
        <td><span class="tag ${v.estado === 'completada' ? 'tag-green' : 'tag-red'}">${v.estado}</span></td>
        <td>
          ${v.estado === 'completada'
            ? `<button class="btn btn-danger" style="padding:3px 8px;font-size:11px"
                 onclick="anularVenta(${v.id},'${v.numero}')">Anular</button>`
            : '—'}
        </td>
      </tr>
    `).join('');
  }

  // Total del día en el header
  const hoy = new Date().toISOString().substring(0, 10);
  const ventasHoy = ventas.filter(v => (v.creado_en || '').startsWith(hoy) && v.estado === 'completada');
  const totalHoy  = ventasHoy.reduce((s, v) => s + parseFloat(v.subtotal), 0);
  const el = document.getElementById('v-total-hoy');
  if (el && ventasHoy.length) {
    el.textContent = 'HOY: $' + totalHoy.toFixed(2) + ' (' + ventasHoy.length + ' ventas)';
  }
}

// ============================================================
//  ANULAR VENTA
// ============================================================
window.anularVenta = function(id, numero) {
  if (!confirm('¿Anular la venta ' + numero + '? El stock será restaurado.')) return;

  const det = DB.dbQuery("SELECT * FROM ventas_detalle WHERE venta_id = ?", [id]);
  det.forEach(d => {
    const prod     = DB.Productos.getById(d.producto_id);
    const antes    = prod.stock;
    const despues  = antes + d.cantidad;
    DB.dbRun("UPDATE productos SET stock = ? WHERE id = ?", [despues, d.producto_id]);
    DB.dbRun(
      "INSERT INTO movimientos (producto_id, tipo, cantidad, stock_antes, stock_despues, referencia, nota, usuario_id) VALUES (?,'entrada',?,?,?,'Venta anulada','Venta anulada',1)",
      [d.producto_id, d.cantidad, antes, despues]
    );
  });

  DB.dbRun("UPDATE ventas SET estado='anulada' WHERE id=?", [id]);
  DB.saveDB();

  recargarBuscador();
  limpiarProductoSeleccionado();
  renderTablaVentas();
  showToast('Venta ' + numero + ' anulada — stock restaurado');
};

// ============================================================
//  RESUMEN DEL DÍA
// ============================================================
window.mostrarResumen = function() {
  const hoy = new Date().toISOString().substring(0, 10);
  const ventas = DB.dbQuery(`
    SELECT v.numero, v.creado_en,
           vd.cantidad, vd.precio_unit, vd.subtotal,
           p.nombre AS producto_nombre
    FROM ventas v
    JOIN ventas_detalle vd ON vd.venta_id = v.id
    JOIN productos p ON p.id = vd.producto_id
    WHERE date(v.creado_en) = ? AND v.estado = 'completada'
    ORDER BY v.creado_en DESC
  `, [hoy]);

  const body = document.getElementById('modal-resumen-body');

  if (!ventas.length) {
    body.innerHTML = `<div style="text-align:center;padding:32px;color:var(--text-muted);
      font-family:var(--font-mono)">Sin ventas registradas hoy (${hoy})</div>`;
  } else {
    const total = ventas.reduce((s, v) => s + parseFloat(v.subtotal), 0);

    // Agrupa por producto
    const agrupado = {};
    ventas.forEach(v => {
      if (!agrupado[v.producto_nombre]) agrupado[v.producto_nombre] = { cantidad: 0, total: 0 };
      agrupado[v.producto_nombre].cantidad += v.cantidad;
      agrupado[v.producto_nombre].total    += parseFloat(v.subtotal);
    });

    body.innerHTML = `
      <div id="contenido-resumen">
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted);
                    margin-bottom:10px;letter-spacing:0.08em">FECHA: ${hoy}</div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
          <thead>
            <tr style="border-bottom:1px solid var(--border)">
              <th style="text-align:left;padding:8px 10px;font-family:var(--font-mono);
                         font-size:10px;color:var(--text-muted)">PRODUCTO</th>
              <th style="text-align:center;padding:8px 10px;font-family:var(--font-mono);
                         font-size:10px;color:var(--text-muted)">CANTIDAD</th>
              <th style="text-align:right;padding:8px 10px;font-family:var(--font-mono);
                         font-size:10px;color:var(--text-muted)">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(agrupado).map(([nombre, d]) => `
              <tr style="border-bottom:1px solid var(--border-light)">
                <td style="padding:10px 10px;color:var(--text-primary);font-size:13px">${nombre}</td>
                <td style="padding:10px 10px;text-align:center;font-family:var(--font-mono)">${d.cantidad}</td>
                <td style="padding:10px 10px;text-align:right;font-family:var(--font-mono);
                           color:var(--accent)">$${d.total.toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
          <tfoot>
            <tr style="border-top:2px solid var(--border)">
              <td colspan="2" style="padding:12px 10px;font-family:var(--font-mono);
                                     font-weight:600;font-size:14px;color:var(--text-primary)">
                TOTAL DEL DÍA
              </td>
              <td style="padding:12px 10px;text-align:right;font-family:var(--font-mono);
                         font-size:18px;font-weight:600;color:var(--accent)">
                $${total.toFixed(2)}
              </td>
            </tr>
          </tfoot>
        </table>

        <div style="font-family:var(--font-mono);font-size:10px;color:var(--text-muted);
                    letter-spacing:0.08em;margin-bottom:8px">DETALLE POR TRANSACCIÓN</div>
        <table style="width:100%;border-collapse:collapse">
          <thead>
            <tr style="border-bottom:1px solid var(--border)">
              <th style="text-align:left;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">N°</th>
              <th style="text-align:left;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">PRODUCTO</th>
              <th style="text-align:center;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">CANT.</th>
              <th style="text-align:right;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">P.UNIT</th>
              <th style="text-align:right;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">SUBTOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${ventas.map(v => `
              <tr style="border-bottom:1px solid var(--border-light)">
                <td style="padding:7px 10px;font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">${v.numero}</td>
                <td style="padding:7px 10px;font-size:13px">${v.producto_nombre}</td>
                <td style="padding:7px 10px;text-align:center;font-family:var(--font-mono)">${v.cantidad}</td>
                <td style="padding:7px 10px;text-align:right;font-family:var(--font-mono)">$${parseFloat(v.precio_unit).toFixed(2)}</td>
                <td style="padding:7px 10px;text-align:right;font-family:var(--font-mono);color:var(--accent)">$${parseFloat(v.subtotal).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  document.getElementById('modal-resumen').style.display = 'flex';
};

// ============================================================
//  IMPRIMIR RESUMEN
// ============================================================
window.imprimirResumen = function() {
  const hoy      = new Date().toISOString().substring(0, 10);
  const empresa  = DB.Config.get('nombre_empresa') || 'Mi Empresa';
  const contenido = document.getElementById('contenido-resumen');
  if (!contenido) return;

  const win = window.open('', '_blank', 'width=500,height=650');
  win.document.write(`<!DOCTYPE html><html><head>
    <meta charset="UTF-8"/>
    <title>Resumen ${hoy}</title>
    <style>
      body { font-family: 'Courier New', monospace; font-size:12px; color:#111; padding:24px; max-width:420px; margin:auto }
      h2   { text-align:center; font-size:15px; margin-bottom:4px }
      .sub { text-align:center; color:#666; margin-bottom:16px; font-size:11px }
      table { width:100%; border-collapse:collapse; margin-bottom:16px }
      th { font-size:10px; color:#666; padding:5px 6px; border-bottom:1px solid #ccc; text-align:left }
      td { padding:7px 6px; border-bottom:1px solid #eee }
      .right { text-align:right }
      .center{ text-align:center }
      tfoot td { font-weight:bold; font-size:14px; border-top:2px solid #000; padding-top:10px }
      @media print { button { display:none } }
    </style>
  </head><body>
    <h2>${empresa}</h2>
    <div class="sub">RESUMEN DE VENTAS — ${hoy}</div>
    ${contenido.innerHTML.replace(/style="[^"]*color:[^"]*"/g, '').replace(/var\(--[^)]+\)/g, '')}
    <br>
    <div style="text-align:center">
      <button onclick="window.print()" style="padding:8px 20px;cursor:pointer;font-size:13px">🖨 Imprimir / Guardar PDF</button>
    </div>
  </body></html>`);
  win.document.close();
};
