/**
 * proveedores.js — Módulo completo de Proveedores
 */

// ============================================================
//  VISTA
// ============================================================
window.viewProveedores = function() {
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Proveedores</div>
        <div class="page-subtitle">Red de abastecimiento</div>
      </div>
      <button class="btn btn-primary" onclick="abrirModalProveedor()">+ Nuevo Proveedor</button>
    </div>

    <!-- BUSCADOR -->
    <div style="margin-bottom:16px">
      <input class="form-input" id="prov-buscar" placeholder="Buscar por nombre, email o RUC/NIT..."
        style="max-width:420px" oninput="filtrarProveedores(this.value)" />
    </div>

    <!-- TABLA -->
    <div class="table-container">
      <div class="table-header">
        <span class="table-title">PROVEEDORES</span>
        <span id="prov-count" style="font-family:var(--font-mono);font-size:12px;color:var(--text-muted)"></span>
      </div>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Contacto</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>RUC / NIT</th>
            <th>Dirección</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody id="prov-tbody"></tbody>
      </table>
    </div>

    <!-- MODAL FORMULARIO -->
    <div id="modal-prov" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.75);
         z-index:500;align-items:center;justify-content:center">
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                  width:520px;max-width:95vw;max-height:90vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:16px 20px;border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono);font-weight:600" id="modal-prov-title">Nuevo Proveedor</span>
          <button onclick="cerrarModalProveedor()" style="background:none;border:none;
            color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
        </div>
        <div style="padding:20px;display:flex;flex-direction:column;gap:14px">
          <input type="hidden" id="prov-id" />
          <div class="form-group" style="margin:0">
            <label class="form-label">Nombre de la empresa *</label>
            <input class="form-input" id="prov-nombre" placeholder="Razón social o nombre" />
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Nombre del contacto</label>
              <input class="form-input" id="prov-contacto" placeholder="Persona de contacto" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Teléfono</label>
              <input class="form-input" id="prov-telefono" placeholder="Ej: 3001234567" />
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Email</label>
              <input class="form-input" id="prov-email" placeholder="correo@empresa.com" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">RUC / NIT</label>
              <input class="form-input" id="prov-ruc" placeholder="Número de identificación" />
            </div>
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Dirección</label>
            <input class="form-input" id="prov-direccion" placeholder="Dirección de la empresa" />
          </div>
          <div id="prov-msg" style="display:none" class="alert"></div>
        </div>
        <div style="padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-outline" onclick="cerrarModalProveedor()">Cancelar</button>
          <button class="btn btn-primary" onclick="guardarProveedor()">Guardar</button>
        </div>
      </div>
    </div>

    <!-- MODAL HISTORIAL -->
    <div id="modal-prov-historial" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.75);
         z-index:500;align-items:center;justify-content:center">
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                  width:620px;max-width:95vw;max-height:85vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:16px 20px;border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono);font-weight:600" id="prov-historial-title">Historial</span>
          <button onclick="document.getElementById('modal-prov-historial').style.display='none'"
            style="background:none;border:none;color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
        </div>
        <div id="prov-historial-body" style="padding:20px"></div>
      </div>
    </div>
  `;
};

// ============================================================
//  CONTROLADOR
// ============================================================
window.initProveedores = function() {
  renderTablaProveedores();
};

function renderTablaProveedores(filtro) {
  let proveedores = DB.Proveedores.getAll();
  if (filtro) {
    const q = filtro.toLowerCase();
    proveedores = proveedores.filter(p =>
      p.nombre.toLowerCase().includes(q) ||
      (p.email || '').toLowerCase().includes(q) ||
      (p.ruc   || '').toLowerCase().includes(q)
    );
  }

  const tbody = document.getElementById('prov-tbody');
  const count = document.getElementById('prov-count');
  if (!tbody) return;

  if (count) count.textContent = proveedores.length + ' registro(s)';

  if (!proveedores.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:28px">Sin proveedores registrados</td></tr>';
    return;
  }

  tbody.innerHTML = proveedores.map(p => `
    <tr>
      <td style="font-weight:500;color:var(--text-primary)">${p.nombre}</td>
      <td style="font-size:12px;color:var(--text-secondary)">${p.contacto || '—'}</td>
      <td style="font-family:var(--font-mono);font-size:12px">${p.telefono || '—'}</td>
      <td style="font-size:12px">${p.email || '—'}</td>
      <td style="font-family:var(--font-mono);font-size:12px">${p.ruc || '—'}</td>
      <td style="font-size:12px;color:var(--text-secondary)">${p.direccion || '—'}</td>
      <td>
        <div style="display:flex;gap:6px">
          <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
            onclick="verHistorialProveedor(${p.id},'${p.nombre.replace(/'/g,"\\'")}')">Historial</button>
          <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
            onclick="editarProveedor(${p.id})">Editar</button>
          <button class="btn btn-danger" style="padding:3px 8px;font-size:11px"
            onclick="eliminarProveedor(${p.id},'${p.nombre.replace(/'/g,"\\'")}')">×</button>
        </div>
      </td>
    </tr>
  `).join('');
}

window.filtrarProveedores = function(val) {
  renderTablaProveedores(val);
};

// ── MODAL FORMULARIO ──
window.abrirModalProveedor = function() {
  ['prov-id','prov-nombre','prov-contacto','prov-telefono',
   'prov-email','prov-ruc','prov-direccion'].forEach(id => {
    document.getElementById(id).value = '';
  });
  document.getElementById('prov-msg').style.display = 'none';
  document.getElementById('modal-prov-title').textContent = 'Nuevo Proveedor';
  document.getElementById('modal-prov').style.display = 'flex';
};

window.cerrarModalProveedor = function() {
  document.getElementById('modal-prov').style.display = 'none';
};

window.editarProveedor = function(id) {
  const p = DB.Proveedores.getById(id);
  if (!p) return;
  document.getElementById('prov-id').value        = p.id;
  document.getElementById('prov-nombre').value    = p.nombre;
  document.getElementById('prov-contacto').value  = p.contacto  || '';
  document.getElementById('prov-telefono').value  = p.telefono  || '';
  document.getElementById('prov-email').value     = p.email     || '';
  document.getElementById('prov-ruc').value       = p.ruc       || '';
  document.getElementById('prov-direccion').value = p.direccion || '';
  document.getElementById('prov-msg').style.display = 'none';
  document.getElementById('modal-prov-title').textContent = 'Editar Proveedor';
  document.getElementById('modal-prov').style.display = 'flex';
};

window.guardarProveedor = function() {
  const msgEl = document.getElementById('prov-msg');
  msgEl.style.display = 'none';

  const id       = document.getElementById('prov-id').value;
  const nombre   = document.getElementById('prov-nombre').value.trim();
  const contacto = document.getElementById('prov-contacto').value.trim();
  const telefono = document.getElementById('prov-telefono').value.trim();
  const email    = document.getElementById('prov-email').value.trim();
  const ruc      = document.getElementById('prov-ruc').value.trim();
  const dir      = document.getElementById('prov-direccion').value.trim();

  if (!nombre) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = 'El nombre es obligatorio.';
    msgEl.style.display = 'block';
    return;
  }

  if (id) {
    DB.dbRun(
      "UPDATE proveedores SET nombre=?,contacto=?,telefono=?,email=?,ruc=?,direccion=? WHERE id=?",
      [nombre, contacto, telefono, email, ruc, dir, id]
    );
    DB.saveDB();
    showToast('Proveedor actualizado');
  } else {
    DB.Proveedores.create({ nombre, contacto, telefono, email, ruc, direccion: dir });
    showToast('Proveedor registrado');
  }

  cerrarModalProveedor();
  renderTablaProveedores();
};

window.eliminarProveedor = function(id, nombre) {
  if (!confirm('¿Eliminar al proveedor "' + nombre + '"?')) return;
  DB.Proveedores.delete(id);
  renderTablaProveedores();
  showToast('Proveedor eliminado');
};

// ── HISTORIAL ──
window.verHistorialProveedor = function(id, nombre) {
  const compras = DB.dbQuery(`
    SELECT c.numero, c.creado_en, c.estado,
           p.nombre AS producto_nombre, cd.cantidad, cd.precio_unit, cd.subtotal
    FROM compras c
    JOIN compras_detalle cd ON cd.compra_id = c.id
    JOIN productos p ON p.id = cd.producto_id
    WHERE c.proveedor_id = ? AND c.estado = 'recibida'
    ORDER BY c.creado_en DESC
  `, [id]);

  document.getElementById('prov-historial-title').textContent = 'Historial de compras — ' + nombre;

  const body = document.getElementById('prov-historial-body');

  if (!compras.length) {
    body.innerHTML = `<div style="text-align:center;padding:32px;color:var(--text-muted);
      font-family:var(--font-mono)">Este proveedor no tiene compras registradas</div>`;
  } else {
    const total = compras.reduce((s, c) => s + parseFloat(c.subtotal), 0);
    body.innerHTML = `
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="border-bottom:1px solid var(--border)">
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:left">N°</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:left">FECHA</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:left">PRODUCTO</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:center">CANT.</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:right">P.UNIT</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:right">TOTAL</th>
          </tr>
        </thead>
        <tbody>
          ${compras.map(c => `
            <tr style="border-bottom:1px solid var(--border-light)">
              <td style="padding:9px 10px;font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">${c.numero}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);font-size:11px">${(c.creado_en||'').substring(0,10)}</td>
              <td style="padding:9px 10px;font-size:13px">${c.producto_nombre}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);text-align:center">${c.cantidad}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);text-align:right">$${parseFloat(c.precio_unit).toFixed(2)}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);text-align:right;color:var(--green)">$${parseFloat(c.subtotal).toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
        <tfoot>
          <tr style="border-top:2px solid var(--border)">
            <td colspan="5" style="padding:12px 10px;font-family:var(--font-mono);font-weight:600;color:var(--text-primary)">TOTAL COMPRADO</td>
            <td style="padding:12px 10px;text-align:right;font-family:var(--font-mono);font-size:16px;font-weight:600;color:var(--green)">$${total.toFixed(2)}</td>
          </tr>
        </tfoot>
      </table>`;
  }

  document.getElementById('modal-prov-historial').style.display = 'flex';
};
