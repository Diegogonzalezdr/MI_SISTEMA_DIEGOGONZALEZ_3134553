/**
 * email.js — Envío de facturas por email con EmailJS
 * 
 * CONFIGURACIÓN REQUERIDA:
 * 1. Crear cuenta gratuita en emailjs.com
 * 2. Crear un Email Service (Gmail, Outlook, etc.)
 * 3. Crear un Email Template con las variables del sistema
 * 4. Copiar Public Key, Service ID y Template ID
 * 5. Pegarlos en Configuración → API e Integraciones
 * 
 * Plan gratuito: 200 emails/mes
 */

// ── Carga EmailJS desde CDN si no está disponible ──
function cargarEmailJS() {
  return new Promise((resolve, reject) => {
    if (window.emailjs) { resolve(); return; }
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
    s.onload  = () => { resolve(); };
    s.onerror = () => reject(new Error('No se pudo cargar EmailJS. Verifica tu conexión.'));
    document.head.appendChild(s);
  });
}

// ============================================================
//  ENVIAR FACTURA POR EMAIL
// ============================================================
async function enviarFacturaEmail(facturaId, emailDestino) {
  const factura = DB.dbGet("SELECT * FROM facturas WHERE id = ?", [facturaId]);
  const detalle = DB.dbQuery("SELECT * FROM facturas_detalle WHERE factura_id = ?", [facturaId]);

  if (!factura) throw new Error('Factura no encontrada.');

  const publicKey  = DB.Config.get('emailjs_public_key')  || '';
  const serviceId  = DB.Config.get('emailjs_service_id')  || '';
  const templateId = DB.Config.get('emailjs_template_id') || '';

  if (!publicKey || !serviceId || !templateId) {
    throw new Error('EmailJS no configurado. Ve a Configuración → API e Integraciones.');
  }

  await cargarEmailJS();
  emailjs.init(publicKey);

  const empresa = {
    razon:  DB.Config.get('razon_social') || DB.Config.get('nombre_empresa') || 'Mi Empresa',
    nit:    DB.Config.get('nit')           || '',
    email:  DB.Config.get('email_empresa') || '',
    tel:    DB.Config.get('telefono_empresa') || '',
  };

  const moneda = DB.Config.get('moneda') || 'COP';

  const itemsHtml = detalle.map((d, i) => `
    <tr style="background:${i%2===0?'#f8fafc':'#fff'}">
      <td style="padding:6px 10px;font-size:12px">${d.descripcion}</td>
      <td style="padding:6px 10px;text-align:center;font-size:12px">${d.cantidad}</td>
      <td style="padding:6px 10px;text-align:right;font-family:monospace;font-size:12px">
        ${formatMoneyEmail(d.precio_unit, moneda)}
      </td>
      <td style="padding:6px 10px;text-align:right;font-family:monospace;font-size:12px;font-weight:bold">
        ${formatMoneyEmail(d.subtotal, moneda)}
      </td>
    </tr>`).join('');

  const templateParams = {
    // Datos del emisor
    empresa_nombre:   empresa.razon,
    empresa_nit:      empresa.nit,
    empresa_email:    empresa.email,
    empresa_telefono: empresa.tel,

    // Datos de la factura
    factura_numero:   factura.numero,
    factura_fecha:    factura.fecha_emision,
    factura_venc:     factura.fecha_vencimiento || 'Contado',
    factura_cufe:     factura.cufe || '',
    forma_pago:       factura.forma_pago === 'contado' ? 'Contado' : 'Crédito',
    medio_pago:       mapearMedioPagoTexto(factura.medio_pago),
    notas:            factura.notas || '',

    // Datos del cliente
    cliente_nombre:   factura.cliente_nombre,
    cliente_nit:      factura.cliente_nit || '',
    cliente_email:    emailDestino || factura.cliente_email || '',
    cliente_dir:      factura.cliente_dir || '',

    // Ítems en HTML
    items_html:       itemsHtml,

    // Totales
    subtotal:         formatMoneyEmail(factura.subtotal, moneda),
    iva_pct:          factura.iva_pct + '%',
    iva_valor:        formatMoneyEmail(factura.iva_valor, moneda),
    total:            formatMoneyEmail(factura.total, moneda),

    // Destinatario
    to_email:         emailDestino || factura.cliente_email || '',
    to_name:          factura.cliente_nombre,
    reply_to:         empresa.email,
  };

  const result = await emailjs.send(serviceId, templateId, templateParams);

  if (result.status === 200) {
    DB.Notificaciones.create('exito', 'Factura enviada por email',
      `La factura ${factura.numero} fue enviada a ${emailDestino || factura.cliente_email}`
    );
    if (typeof updateNotifBadge === 'function') updateNotifBadge();
    return true;
  } else {
    throw new Error('Error al enviar email: ' + result.text);
  }
}

function formatMoneyEmail(val, moneda = 'COP') {
  return new Intl.NumberFormat('es-CO', {
    style:'currency', currency: moneda || 'COP', minimumFractionDigits:0
  }).format(val || 0);
}

function mapearMedioPagoTexto(medio) {
  const m = {
    efectivo:'Efectivo', transferencia:'Transferencia bancaria',
    tarjeta_credito:'Tarjeta de crédito', tarjeta_debito:'Tarjeta de débito',
    cheque:'Cheque', otro:'Otro'
  };
  return m[medio] || medio || 'Efectivo';
}

// ============================================================
//  MODAL ENVIAR POR EMAIL
// ============================================================
window.abrirModalEnviarEmail = function(facturaId) {
  const factura = DB.dbGet("SELECT * FROM facturas WHERE id = ?", [facturaId]);
  if (!factura) return;

  // Crea modal dinámicamente
  const existing = document.getElementById('modal-enviar-email');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'modal-enviar-email';
  modal.style.cssText = 'display:flex;position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:600;align-items:center;justify-content:center';
  modal.innerHTML = `
    <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                width:460px;max-width:95vw">
      <div style="display:flex;justify-content:space-between;align-items:center;
                  padding:16px 20px;border-bottom:1px solid var(--border)">
        <span style="font-family:var(--font-mono);font-weight:600">
          📧 Enviar factura por email
        </span>
        <button onclick="document.getElementById('modal-enviar-email').remove()"
          style="background:none;border:none;color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
      </div>
      <div style="padding:20px;display:flex;flex-direction:column;gap:14px">
        <div style="background:var(--bg-elevated);border-radius:4px;padding:10px 14px;font-size:13px">
          <span style="color:var(--text-muted)">Factura:</span>
          <span style="font-family:var(--font-mono);color:var(--accent);margin-left:8px">${factura.numero}</span>
          <span style="color:var(--text-muted);margin-left:12px">Cliente:</span>
          <span style="margin-left:8px">${factura.cliente_nombre}</span>
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Email del destinatario *</label>
          <input class="form-input" id="email-destino" type="email"
            value="${factura.cliente_email || ''}"
            placeholder="correo@cliente.com" />
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Mensaje personalizado (opcional)</label>
          <textarea class="form-input" id="email-mensaje" rows="3"
            placeholder="Estimado cliente, adjunto encontrará su factura electrónica..."
            style="resize:vertical"></textarea>
        </div>
        <div id="email-send-msg" style="display:none" class="alert"></div>
      </div>
      <div style="padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px">
        <button class="btn btn-outline"
          onclick="document.getElementById('modal-enviar-email').remove()">Cancelar</button>
        <button class="btn btn-primary" id="btn-enviar-email-confirm"
          onclick="confirmarEnvioEmail(${facturaId})">
          📧 Enviar
        </button>
      </div>
    </div>`;
  document.body.appendChild(modal);
};

window.confirmarEnvioEmail = async function(facturaId) {
  const emailDest = document.getElementById('email-destino').value.trim();
  const msgEl     = document.getElementById('email-send-msg');
  const btn       = document.getElementById('btn-enviar-email-confirm');

  if (!emailDest || !emailDest.includes('@')) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = 'Ingresa un email válido.';
    msgEl.style.display = 'block';
    return;
  }

  btn.textContent = '⏳ Enviando...';
  btn.disabled = true;
  msgEl.style.display = 'none';

  try {
    await enviarFacturaEmail(facturaId, emailDest);
    msgEl.className = 'alert alert-success';
    msgEl.textContent = '✓ Factura enviada correctamente a ' + emailDest;
    msgEl.style.display = 'block';
    btn.textContent = '✓ Enviado';
    setTimeout(() => {
      const m = document.getElementById('modal-enviar-email');
      if (m) m.remove();
    }, 2500);
  } catch(err) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = '✗ ' + err.message;
    msgEl.style.display = 'block';
    btn.textContent = '📧 Reintentar';
    btn.disabled = false;
  }
};

// ============================================================
//  VISTA — sección de configuración EmailJS
// ============================================================
window.renderSeccionEmail = function() {
  const pubKey     = DB.Config.get('emailjs_public_key')  || '';
  const serviceId  = DB.Config.get('emailjs_service_id')  || '';
  const templateId = DB.Config.get('emailjs_template_id') || '';

  return `
    <div style="margin-top:20px">
      <div style="margin-bottom:14px">
        <div style="font-family:var(--font-mono);font-size:13px;font-weight:600;color:var(--text-primary)">
          EmailJS — Envío de facturas por email
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:2px">
          Sin servidor. Funciona directo desde el navegador.
          <a href="https://emailjs.com" target="_blank" style="color:var(--accent)">emailjs.com</a>
          — Plan gratuito: 200 emails/mes.
        </div>
      </div>

      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">CREDENCIALES EMAILJS</span></div>
        <div style="padding:16px;display:flex;flex-direction:column;gap:12px">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Public Key *</label>
              <input class="form-input" id="ejs-public-key"
                value="${pubKey}" placeholder="Tu Public Key" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Service ID *</label>
              <input class="form-input" id="ejs-service-id"
                value="${serviceId}" placeholder="service_xxxxxx" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Template ID *</label>
              <input class="form-input" id="ejs-template-id"
                value="${templateId}" placeholder="template_xxxxxx" />
            </div>
          </div>

          <div id="email-config-msg" style="display:none" class="alert"></div>

          <div style="display:flex;gap:8px">
            <button class="btn btn-outline" onclick="testEmailJS()">
              📧 Enviar email de prueba
            </button>
            <button class="btn btn-primary" onclick="guardarConfigEmail()">
              Guardar credenciales
            </button>
          </div>
        </div>
      </div>

      <div class="table-container" style="padding:16px">
        <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:0.1em;
                    color:var(--text-muted);margin-bottom:12px">CÓMO CONFIGURAR EMAILJS</div>
        ${[
          ['1', 'Crea cuenta gratis en emailjs.com'],
          ['2', 'Ve a Email Services → Add New Service → conecta tu Gmail u Outlook'],
          ['3', 'Ve a Email Templates → Create New Template'],
          ['4', 'En el template usa estas variables: {{factura_numero}}, {{cliente_nombre}}, {{total}}, {{to_email}}, {{empresa_nombre}}'],
          ['5', 'Ve a Account → General → copia tu Public Key'],
          ['6', 'Pega Public Key, Service ID y Template ID aquí y guarda'],
        ].map(([n,t]) => `
          <div style="display:flex;gap:10px;margin-bottom:10px;align-items:flex-start">
            <div style="background:var(--green);color:#fff;border-radius:50%;width:22px;height:22px;
                        display:flex;align-items:center;justify-content:center;
                        font-family:var(--font-mono);font-size:11px;font-weight:600;flex-shrink:0">${n}</div>
            <div style="font-size:13px;color:var(--text-secondary);padding-top:2px">${t}</div>
          </div>`).join('')}

        <div style="margin-top:14px;padding:12px;background:var(--bg-elevated);border-radius:4px;
                    border:1px dashed var(--border)">
          <div style="font-family:var(--font-mono);font-size:11px;color:var(--accent);margin-bottom:6px">
            VARIABLES DISPONIBLES EN EL TEMPLATE
          </div>
          <div style="font-size:11px;color:var(--text-muted);font-family:var(--font-mono);line-height:2">
            {{empresa_nombre}} {{empresa_nit}} {{factura_numero}} {{factura_fecha}}<br>
            {{cliente_nombre}} {{cliente_nit}} {{subtotal}} {{iva_valor}} {{total}}<br>
            {{forma_pago}} {{medio_pago}} {{items_html}} {{notas}} {{factura_cufe}}
          </div>
        </div>
      </div>
    </div>
  `;
};

window.guardarConfigEmail = function() {
  const pubKey     = document.getElementById('ejs-public-key').value.trim();
  const serviceId  = document.getElementById('ejs-service-id').value.trim();
  const templateId = document.getElementById('ejs-template-id').value.trim();
  const msgEl = document.getElementById('email-config-msg');

  if (!pubKey || !serviceId || !templateId) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = 'Completa los tres campos.';
    msgEl.style.display = 'block'; return;
  }

  DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['emailjs_public_key', pubKey, 'EmailJS Public Key']);
  DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['emailjs_service_id', serviceId, 'EmailJS Service ID']);
  DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['emailjs_template_id', templateId, 'EmailJS Template ID']);
  DB.saveDB();

  msgEl.className = 'alert alert-success';
  msgEl.textContent = '✓ Credenciales guardadas correctamente.';
  msgEl.style.display = 'block';
  if (typeof showToast === 'function') showToast('Credenciales EmailJS guardadas');
};

window.testEmailJS = async function() {
  const msgEl = document.getElementById('email-config-msg');
  const emailEmpresa = DB.Config.get('email_empresa') || '';
  if (!emailEmpresa) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = 'Primero configura el email de la empresa en Mis documentos.';
    msgEl.style.display = 'block'; return;
  }
  guardarConfigEmail();
  msgEl.className = 'alert alert-info';
  msgEl.textContent = '⏳ Enviando email de prueba a ' + emailEmpresa + '...';
  msgEl.style.display = 'block';

  try {
    await cargarEmailJS();
    const pubKey    = DB.Config.get('emailjs_public_key')  || '';
    const serviceId = DB.Config.get('emailjs_service_id')  || '';
    const templateId= DB.Config.get('emailjs_template_id') || '';
    emailjs.init(pubKey);
    await emailjs.send(serviceId, templateId, {
      to_email:       emailEmpresa,
      to_name:        'Administrador',
      empresa_nombre: DB.Config.get('razon_social') || 'SistemaGest',
      factura_numero: 'TEST-001',
      total:          '$0',
      cliente_nombre: 'Cliente de prueba',
      items_html:     '<tr><td colspan="4" style="padding:8px">Ítem de prueba</td></tr>',
    });
    msgEl.className = 'alert alert-success';
    msgEl.textContent = '✓ Email de prueba enviado a ' + emailEmpresa + '. Revisa tu bandeja.';
  } catch(err) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = '✗ ' + err.message;
  }
};

window.EmailService = { enviar: enviarFacturaEmail };
