/**
 * facturacion.js — Módulo de Facturación Electrónica
 * Cumple con requisitos DIAN Colombia
 */

// ============================================================
//  HELPERS
// ============================================================

function generarCUFE(numero, fecha, nit, total) {
  // CUFE simplificado (en producción real se genera con firma digital DIAN)
  const base = numero + fecha + nit + total + 'SistemaGest';
  let hash = 0;
  for (let i = 0; i < base.length; i++) {
    const char = base.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  const hex = Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
  return `CUFE-${numero}-${hex}-${Date.now().toString(36).toUpperCase()}`;
}

function generarNumeroFactura() {
  const last = DB.dbGet("SELECT numero FROM facturas ORDER BY id DESC LIMIT 1");
  if (!last) return 'FE-0001';
  const n = parseInt(last.numero.replace('FE-', '')) + 1;
  return 'FE-' + String(n).padStart(4, '0');
}

function formatFecha(fecha) {
  if (!fecha) return '';
  const d = new Date(fecha);
  return d.toLocaleDateString('es-CO', { year:'numeric', month:'long', day:'numeric' });
}

function formatMoney(val) {
  return new Intl.NumberFormat('es-CO', { style:'currency', currency:'COP', minimumFractionDigits:0 }).format(val || 0);
}

// ============================================================
//  SCHEMA — tabla facturas
// ============================================================
function initFacturasDB() {
  DB.dbRun(`CREATE TABLE IF NOT EXISTS facturas (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    numero          TEXT    UNIQUE NOT NULL,
    cufe            TEXT    NOT NULL,
    cliente_id      INTEGER,
    cliente_nombre  TEXT    NOT NULL,
    cliente_nit     TEXT,
    cliente_dir     TEXT,
    cliente_email   TEXT,
    cliente_tel     TEXT,
    subtotal        REAL    NOT NULL DEFAULT 0,
    descuento       REAL    NOT NULL DEFAULT 0,
    iva_pct         REAL    NOT NULL DEFAULT 19,
    iva_valor       REAL    NOT NULL DEFAULT 0,
    total           REAL    NOT NULL DEFAULT 0,
    forma_pago      TEXT    NOT NULL DEFAULT 'contado',
    medio_pago      TEXT    NOT NULL DEFAULT 'efectivo',
    estado          TEXT    NOT NULL DEFAULT 'pendiente',
    notas           TEXT,
    fecha_emision   TEXT    NOT NULL,
    fecha_vencimiento TEXT,
    creado_en       TEXT    NOT NULL DEFAULT (datetime('now'))
  )`);

  DB.dbRun(`CREATE TABLE IF NOT EXISTS facturas_detalle (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    factura_id  INTEGER NOT NULL,
    producto_id INTEGER,
    descripcion TEXT    NOT NULL,
    cantidad    REAL    NOT NULL,
    precio_unit REAL    NOT NULL,
    descuento   REAL    NOT NULL DEFAULT 0,
    iva_pct     REAL    NOT NULL DEFAULT 19,
    subtotal    REAL    NOT NULL
  )`);

  DB.saveDB();
}

// ============================================================
//  ESTADO DEL FORMULARIO
// ============================================================
let itemsFactura = [];
let ivaPct = 19;

// ============================================================
//  VISTA PRINCIPAL
// ============================================================
window.viewFacturacion = function() {
  return `
    <div id="fact-seccion-bienvenida">
      <!-- Bienvenida -->
      <div style="text-align:center;padding:48px 24px 32px">
        <div style="font-size:48px;margin-bottom:16px">🧾</div>
        <div style="font-family:var(--font-mono);font-size:22px;font-weight:600;
                    color:var(--text-primary);margin-bottom:8px">
          Facturación Electrónica
        </div>
        <div style="font-size:14px;color:var(--text-secondary);max-width:480px;
                    margin:0 auto 32px;line-height:1.6">
          Genera facturas electrónicas que cumplen con los requisitos de la DIAN.
          Los datos de tu empresa se toman automáticamente de los documentos registrados.
        </div>
        <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap">
          <button class="btn btn-outline" style="padding:12px 28px;font-size:14px"
            onclick="mostrarMisFacturas()">
            📋 Mis Facturas
          </button>
          <button class="btn btn-primary" style="padding:12px 28px;font-size:14px"
            onclick="mostrarCrearFactura()">
            ✚ Crear Nueva Factura
          </button>
        </div>
      </div>

      <!-- Resumen rápido -->
      <div id="fact-resumen-cards"></div>
    </div>

    <!-- Sección mis facturas -->
    <div id="fact-seccion-lista" style="display:none"></div>

    <!-- Sección crear factura -->
    <div id="fact-seccion-crear" style="display:none"></div>

    <!-- Modal vista previa / PDF -->
    <div id="modal-factura-preview" style="display:none;position:fixed;inset:0;
         background:rgba(0,0,0,0.85);z-index:600;align-items:center;justify-content:center;
         overflow-y:auto;padding:20px">
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                  width:720px;max-width:98vw;max-height:95vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:16px 20px;border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono);font-weight:600">
            Vista previa — Factura Electrónica
          </span>
          <div style="display:flex;gap:8px">
            <button class="btn btn-primary" onclick="imprimirFacturaElectronica()">
              🖨 Imprimir / PDF
            </button>
            <button class="btn btn-outline"
              onclick="document.getElementById('modal-factura-preview').style.display='none'">
              Cerrar
            </button>
          </div>
        </div>
        <div id="factura-preview-body" style="padding:24px"></div>
      </div>
    </div>
  `;
};

// ============================================================
//  INIT
// ============================================================
window.initFacturacion = function() {
  initFacturasDB();
  renderResumenCards();
};

function renderResumenCards() {
  const total   = DB.dbQuery("SELECT COUNT(*) as n FROM facturas")[0]?.n || 0;
  const pendientes = DB.dbQuery("SELECT COUNT(*) as n FROM facturas WHERE estado='pendiente'")[0]?.n || 0;
  const pagadas    = DB.dbQuery("SELECT COUNT(*) as n FROM facturas WHERE estado='pagada'")[0]?.n || 0;
  const anuladas   = DB.dbQuery("SELECT COUNT(*) as n FROM facturas WHERE estado='anulada'")[0]?.n || 0;
  const totalVal   = DB.dbGet("SELECT SUM(total) as s FROM facturas WHERE estado!='anulada'")?.s || 0;

  const el = document.getElementById('fact-resumen-cards');
  if (!el) return;
  el.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px;
                max-width:800px;margin:0 auto;padding:0 24px 32px">
      ${[
        ['TOTAL FACTURAS', total, 'var(--accent)'],
        ['PENDIENTES',     pendientes, 'var(--yellow)'],
        ['PAGADAS',        pagadas, 'var(--green)'],
        ['ANULADAS',       anuladas, 'var(--red)'],
        ['VALOR TOTAL',    formatMoney(totalVal), 'var(--accent)'],
      ].map(([label, val, color]) => `
        <div class="card" style="text-align:center">
          <div class="card-label">${label}</div>
          <div class="card-value" style="color:${color};font-size:20px">${val}</div>
        </div>
      `).join('')}
    </div>`;
}

// ============================================================
//  MIS FACTURAS
// ============================================================
window.mostrarMisFacturas = function() {
  document.getElementById('fact-seccion-bienvenida').style.display = 'none';
  document.getElementById('fact-seccion-crear').style.display = 'none';
  document.getElementById('fact-seccion-lista').style.display = 'block';
  renderListaFacturas();
};

function renderListaFacturas() {
  const facturas = DB.dbQuery(
    "SELECT * FROM facturas ORDER BY creado_en DESC LIMIT 100"
  );

  document.getElementById('fact-seccion-lista').innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Mis Facturas</div>
        <div class="page-subtitle">Historial de facturas electrónicas</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-outline" onclick="volverBienvenida()">← Volver</button>
        <button class="btn btn-primary" onclick="mostrarCrearFactura()">✚ Nueva Factura</button>
      </div>
    </div>
    <div class="table-container">
      <div class="table-header"><span class="table-title">FACTURAS ELECTRÓNICAS</span></div>
      <table>
        <thead>
          <tr>
            <th>N° Factura</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Total</th>
            <th>IVA</th>
            <th>Forma pago</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          ${facturas.length ? facturas.map(f => `
            <tr style="${f.estado==='anulada'?'opacity:0.45':''}">
              <td style="font-family:var(--font-mono);font-size:11px;color:var(--accent)">${f.numero}</td>
              <td style="font-family:var(--font-mono);font-size:11px">${(f.fecha_emision||'').substring(0,10)}</td>
              <td>${f.cliente_nombre}</td>
              <td style="font-family:var(--font-mono);color:var(--accent)">${formatMoney(f.total)}</td>
              <td style="font-family:var(--font-mono);font-size:12px">${formatMoney(f.iva_valor)}</td>
              <td style="font-size:12px">${f.forma_pago==='contado'?'Contado':'Crédito'}</td>
              <td>
                <span class="tag ${f.estado==='pagada'?'tag-green':f.estado==='anulada'?'tag-red':'tag-yellow'}">
                  ${f.estado.toUpperCase()}
                </span>
              </td>
              <td>
                <div style="display:flex;gap:4px">
                  <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
                    onclick="verFactura(${f.id})">Ver</button>
                  <button class="btn btn-outline" style="padding:3px 8px;font-size:11px;color:var(--accent);border-color:var(--accent)"
                    onclick="abrirModalEnviarEmail(${f.id})">📧</button>
                  ${f.estado_dian ? `
                    <span class="tag tag-green" style="font-size:10px">DIAN ✓</span>
                  ` : `
                    <button class="btn btn-outline" id="btn-dian-${f.id}"
                      style="padding:3px 8px;font-size:11px;color:var(--yellow);border-color:var(--yellow)"
                      onclick="enviarFacturaADIAN(${f.id})">🏛 DIAN</button>
                  `}
                  ${f.estado==='pendiente'?`
                    <button class="btn btn-outline" style="padding:3px 8px;font-size:11px;color:var(--green);border-color:var(--green)"
                      onclick="marcarPagada(${f.id})">Pagada</button>
                    <button class="btn btn-danger" style="padding:3px 8px;font-size:11px"
                      onclick="anularFactura(${f.id},'${f.numero}')">Anular</button>
                  ` : ''}
                </div>
              </td>
            </tr>
          `).join('') : `
            <tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:32px">
              No hay facturas registradas aún
            </td></tr>
          `}
        </tbody>
      </table>
    </div>`;
}

// ============================================================
//  CREAR FACTURA
// ============================================================
window.mostrarCrearFactura = function() {
  itemsFactura = [];
  ivaPct = parseFloat(DB.Config.get('impuesto_pct') || '19');

  document.getElementById('fact-seccion-bienvenida').style.display = 'none';
  document.getElementById('fact-seccion-lista').style.display = 'none';
  document.getElementById('fact-seccion-crear').style.display = 'block';

  // Datos de la empresa desde config
  const empresa = {
    razon:    DB.Config.get('razon_social')    || DB.Config.get('nombre_empresa') || '',
    nit:      DB.Config.get('nit')             || '',
    dir:      DB.Config.get('direccion_empresa')|| '',
    tel:      DB.Config.get('telefono_empresa') || '',
    email:    DB.Config.get('email_empresa')    || '',
    regimen:  DB.Config.get('regimen_fiscal')   || '',
  };

  const clientes = DB.Clientes.getAll();
  const hoy = new Date().toISOString().substring(0,10);
  const numeroFact = generarNumeroFactura();

  document.getElementById('fact-seccion-crear').innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Crear Factura Electrónica</div>
        <div class="page-subtitle">Factura de venta — ${numeroFact}</div>
      </div>
      <button class="btn btn-outline" onclick="volverBienvenida()">← Volver</button>
    </div>

    ${!empresa.razon || !empresa.nit ? `
      <div class="alert alert-error" style="margin-bottom:16px">
        ⚠ Faltan datos de la empresa. Ve a <strong>Configuración → Mis documentos</strong>
        y registra la razón social y el NIT antes de generar facturas.
      </div>` : ''}

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">

      <!-- Datos del emisor -->
      <div class="table-container">
        <div class="table-header"><span class="table-title">DATOS DEL EMISOR</span></div>
        <div style="padding:14px;font-size:13px;line-height:2">
          <div><span style="color:var(--text-muted);font-family:var(--font-mono);font-size:10px">RAZÓN SOCIAL</span><br>
            <strong style="color:var(--text-primary)">${empresa.razon || '— Sin registrar —'}</strong></div>
          <div><span style="color:var(--text-muted);font-family:var(--font-mono);font-size:10px">NIT</span><br>
            <span style="font-family:var(--font-mono)">${empresa.nit || '— Sin registrar —'}</span></div>
          <div><span style="color:var(--text-muted);font-family:var(--font-mono);font-size:10px">DIRECCIÓN</span><br>
            ${empresa.dir || '—'}</div>
          <div><span style="color:var(--text-muted);font-family:var(--font-mono);font-size:10px">RÉGIMEN</span><br>
            ${empresa.regimen || '—'}</div>
        </div>
      </div>

      <!-- Datos del adquiriente -->
      <div class="table-container">
        <div class="table-header"><span class="table-title">DATOS DEL ADQUIRIENTE</span></div>
        <div style="padding:14px">
          <div class="form-group" style="margin-bottom:10px">
            <label class="form-label">Cliente registrado *</label>
            <select class="form-input" id="fact-cliente-sel" onchange="cargarDatosCliente(this.value)">
              <option value="">— Selecciona un cliente —</option>
              ${clientes.map(c => `<option value="${c.id}">${c.nombre}${c.ruc_dni?' — '+c.ruc_dni:''}</option>`).join('')}
            </select>
          </div>
          <div id="fact-cliente-info" style="font-size:12px;line-height:2;color:var(--text-secondary)">
            Selecciona un cliente para ver sus datos
          </div>
          <input type="hidden" id="fact-cliente-id" />
          <input type="hidden" id="fact-cliente-nombre" />
          <input type="hidden" id="fact-cliente-nit" />
          <input type="hidden" id="fact-cliente-dir" />
          <input type="hidden" id="fact-cliente-email" />
          <input type="hidden" id="fact-cliente-tel" />
        </div>
      </div>
    </div>

    <!-- Detalles de la factura -->
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
      <div class="form-group" style="margin:0">
        <label class="form-label">N° Factura</label>
        <input class="form-input" id="fact-numero" value="${numeroFact}" readonly
          style="font-family:var(--font-mono);background:var(--bg-base)" />
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">Fecha emisión *</label>
        <input class="form-input" type="date" id="fact-fecha-emision" value="${hoy}" />
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">Fecha vencimiento</label>
        <input class="form-input" type="date" id="fact-fecha-vencimiento" />
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">Forma de pago *</label>
        <select class="form-input" id="fact-forma-pago" onchange="toggleMedioPago()">
          <option value="contado">Contado</option>
          <option value="credito">Crédito</option>
        </select>
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">Medio de pago *</label>
        <select class="form-input" id="fact-medio-pago">
          <option value="efectivo">Efectivo</option>
          <option value="transferencia">Transferencia bancaria</option>
          <option value="tarjeta_credito">Tarjeta de crédito</option>
          <option value="tarjeta_debito">Tarjeta de débito</option>
          <option value="cheque">Cheque</option>
          <option value="otro">Otro</option>
        </select>
      </div>
      <div class="form-group" style="margin:0">
        <label class="form-label">IVA (%)</label>
        <input class="form-input" type="number" id="fact-iva" value="${ivaPct}"
          oninput="recalcularFactura()" style="font-family:var(--font-mono)" />
      </div>
    </div>

    <!-- Agregar productos -->
    <div class="table-container" style="margin-bottom:16px">
      <div class="table-header">
        <span class="table-title">ÍTEMS DE LA FACTURA</span>
      </div>
      <div style="padding:14px;display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto;gap:10px;
                  align-items:end;border-bottom:1px solid var(--border)">
        <div>
          <label class="form-label">Producto / Descripción *</label>
          <div style="position:relative">
            <input class="form-input" id="fact-item-desc" placeholder="Buscar o describir..." autocomplete="off"
              oninput="buscarProductoFact(this.value)" />
            <div id="fact-item-resultados" style="display:none;position:absolute;top:100%;left:0;right:0;
                 background:var(--bg-elevated);border:1px solid var(--accent);border-top:none;
                 border-radius:0 0 4px 4px;z-index:200;max-height:180px;overflow-y:auto"></div>
          </div>
          <input type="hidden" id="fact-item-prod-id" />
        </div>
        <div>
          <label class="form-label">Cantidad</label>
          <input class="form-input" type="number" id="fact-item-cant" value="1" min="0.01" step="0.01"
            style="font-family:var(--font-mono)" oninput="actualizarPreviewItem()" />
        </div>
        <div>
          <label class="form-label">Precio unitario</label>
          <input class="form-input" type="number" id="fact-item-precio" placeholder="0.00" min="0" step="100"
            style="font-family:var(--font-mono)" oninput="actualizarPreviewItem()" />
        </div>
        <div>
          <label class="form-label">Desc. % ítem</label>
          <input class="form-input" type="number" id="fact-item-desc-pct" value="0" min="0" max="100"
            style="font-family:var(--font-mono)" oninput="actualizarPreviewItem()" />
        </div>
        <div>
          <label class="form-label" style="opacity:0">.</label>
          <button class="btn btn-primary" onclick="agregarItemFactura()" style="padding:8px 14px">
            + Agregar
          </button>
        </div>
      </div>
      <div style="padding:8px 14px;font-family:var(--font-mono);font-size:12px;color:var(--accent);
                  border-bottom:1px solid var(--border);min-height:32px" id="fact-item-preview">
        Subtotal ítem: $0
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th><th>Descripción</th><th>Cant.</th><th>P.Unit</th>
            <th>Desc.</th><th>IVA</th><th>Subtotal</th><th></th>
          </tr>
        </thead>
        <tbody id="fact-items-tbody">
          <tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:20px">
            Agrega ítems a la factura
          </td></tr>
        </tbody>
      </table>
    </div>

    <!-- Totales + notas -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
      <div class="form-group" style="margin:0">
        <label class="form-label">Notas u observaciones</label>
        <textarea class="form-input" id="fact-notas" rows="4"
          placeholder="Condiciones, observaciones, instrucciones de pago..."
          style="resize:vertical"></textarea>
      </div>
      <div class="table-container">
        <div style="padding:16px">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px">
            <span style="color:var(--text-muted)">Subtotal</span>
            <span style="font-family:var(--font-mono)" id="fact-tot-subtotal">${formatMoney(0)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px">
            <span style="color:var(--text-muted)">Descuentos</span>
            <span style="font-family:var(--font-mono);color:var(--red)" id="fact-tot-descuento">- ${formatMoney(0)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px">
            <span style="color:var(--text-muted)" id="fact-tot-iva-label">IVA (${ivaPct}%)</span>
            <span style="font-family:var(--font-mono)" id="fact-tot-iva">${formatMoney(0)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding-top:12px;
                      border-top:2px solid var(--border);font-size:18px;font-weight:600">
            <span>TOTAL</span>
            <span style="font-family:var(--font-mono);color:var(--accent)" id="fact-tot-total">${formatMoney(0)}</span>
          </div>
        </div>
      </div>
    </div>

    <div id="fact-crear-msg" style="display:none" class="alert"></div>

    <div style="display:flex;gap:10px;justify-content:flex-end">
      <button class="btn btn-outline" onclick="volverBienvenida()">Cancelar</button>
      <button class="btn btn-outline" style="border-color:var(--accent);color:var(--accent)"
        onclick="previsualizarFactura()">👁 Vista previa</button>
      <button class="btn btn-primary" style="padding:10px 24px"
        onclick="guardarFactura()">✓ Guardar Factura</button>
    </div>
  `;

  document.addEventListener('click', function cerrarDropFact(e) {
    if (!e.target.closest('#fact-item-desc') && !e.target.closest('#fact-item-resultados')) {
      const r = document.getElementById('fact-item-resultados');
      if (r) r.style.display = 'none';
    }
  });
};

// ── Cargar datos del cliente al seleccionar ──
window.cargarDatosCliente = function(id) {
  if (!id) return;
  const c = DB.Clientes.getById(parseInt(id));
  if (!c) return;
  document.getElementById('fact-cliente-id').value    = c.id;
  document.getElementById('fact-cliente-nombre').value= c.nombre;
  document.getElementById('fact-cliente-nit').value   = c.ruc_dni  || '';
  document.getElementById('fact-cliente-dir').value   = c.direccion|| '';
  document.getElementById('fact-cliente-email').value = c.email    || '';
  document.getElementById('fact-cliente-tel').value   = c.telefono || '';
  document.getElementById('fact-cliente-info').innerHTML = `
    <div><b style="color:var(--text-primary)">${c.nombre}</b></div>
    <div>NIT/Cédula: <span style="font-family:var(--font-mono)">${c.ruc_dni||'—'}</span></div>
    <div>Email: ${c.email||'—'}</div>
    <div>Teléfono: ${c.telefono||'—'}</div>
    <div>Dirección: ${c.direccion||'—'}</div>`;
};

// ── Buscador de productos en ítem ──
window.buscarProductoFact = function(q) {
  const res = document.getElementById('fact-item-resultados');
  if (!q || q.length < 1) { res.style.display = 'none'; return; }
  const prods = DB.Productos.getAll().filter(p =>
    p.nombre.toLowerCase().includes(q.toLowerCase()) ||
    p.codigo.toLowerCase().includes(q.toLowerCase())
  );
  if (!prods.length) { res.style.display = 'none'; return; }
  res.innerHTML = prods.slice(0,8).map(p => `
    <div style="padding:8px 12px;cursor:pointer;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between"
         onmouseenter="this.style.background='var(--bg-hover)'"
         onmouseleave="this.style.background=''"
         onclick="seleccionarProductoFact(${p.id},'${p.nombre.replace(/'/g,"\\'")}',${p.precio_venta})">
      <div>
        <div style="font-size:13px;color:var(--text-primary)">${p.nombre}</div>
        <div style="font-size:10px;font-family:var(--font-mono);color:var(--text-muted)">${p.codigo} · Stock: ${p.stock}</div>
      </div>
      <div style="font-family:var(--font-mono);color:var(--accent);font-size:13px">
        ${formatMoney(p.precio_venta)}
      </div>
    </div>`).join('');
  res.style.display = 'block';
};

window.seleccionarProductoFact = function(id, nombre, precio) {
  document.getElementById('fact-item-desc').value     = nombre;
  document.getElementById('fact-item-prod-id').value  = id;
  document.getElementById('fact-item-precio').value   = precio;
  document.getElementById('fact-item-resultados').style.display = 'none';
  actualizarPreviewItem();
  document.getElementById('fact-item-cant').focus();
};

window.actualizarPreviewItem = function() {
  const cant   = parseFloat(document.getElementById('fact-item-cant').value)    || 0;
  const precio = parseFloat(document.getElementById('fact-item-precio').value)  || 0;
  const desc   = parseFloat(document.getElementById('fact-item-desc-pct').value)|| 0;
  const sub    = cant * precio * (1 - desc/100);
  document.getElementById('fact-item-preview').textContent = `Subtotal ítem: ${formatMoney(sub)}`;
};

// ── Agregar ítem ──
window.agregarItemFactura = function() {
  const desc   = document.getElementById('fact-item-desc').value.trim();
  const prodId = document.getElementById('fact-item-prod-id').value;
  const cant   = parseFloat(document.getElementById('fact-item-cant').value)    || 0;
  const precio = parseFloat(document.getElementById('fact-item-precio').value)  || 0;
  const descPct= parseFloat(document.getElementById('fact-item-desc-pct').value)|| 0;
  ivaPct = parseFloat(document.getElementById('fact-iva').value) || 19;

  if (!desc)   { showToast('Escribe una descripción'); return; }
  if (cant<=0) { showToast('La cantidad debe ser mayor a 0'); return; }
  if (precio<=0){ showToast('El precio debe ser mayor a 0'); return; }

  const subtotal = cant * precio * (1 - descPct/100);
  itemsFactura.push({ prodId: prodId||null, descripcion: desc, cantidad: cant,
    precio_unit: precio, descuento: descPct, iva_pct: ivaPct, subtotal });

  // Limpia campos
  document.getElementById('fact-item-desc').value     = '';
  document.getElementById('fact-item-prod-id').value  = '';
  document.getElementById('fact-item-cant').value     = '1';
  document.getElementById('fact-item-precio').value   = '';
  document.getElementById('fact-item-desc-pct').value = '0';
  document.getElementById('fact-item-preview').textContent = 'Subtotal ítem: $0';

  renderItemsTabla();
  recalcularFactura();
};

function renderItemsTabla() {
  const tbody = document.getElementById('fact-items-tbody');
  if (!itemsFactura.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:20px">Agrega ítems a la factura</td></tr>';
    return;
  }
  tbody.innerHTML = itemsFactura.map((item, i) => `
    <tr>
      <td style="font-family:var(--font-mono);color:var(--text-muted)">${i+1}</td>
      <td>${item.descripcion}</td>
      <td style="font-family:var(--font-mono);text-align:center">${item.cantidad}</td>
      <td style="font-family:var(--font-mono)">${formatMoney(item.precio_unit)}</td>
      <td style="font-family:var(--font-mono)">${item.descuento}%</td>
      <td style="font-family:var(--font-mono)">${item.iva_pct}%</td>
      <td style="font-family:var(--font-mono);color:var(--accent)">${formatMoney(item.subtotal)}</td>
      <td><button style="background:none;border:none;color:var(--red);cursor:pointer;font-size:16px"
        onclick="eliminarItemFact(${i})">×</button></td>
    </tr>`).join('');
}

window.eliminarItemFact = function(i) {
  itemsFactura.splice(i, 1);
  renderItemsTabla();
  recalcularFactura();
};

window.recalcularFactura = function() {
  ivaPct = parseFloat(document.getElementById('fact-iva')?.value) || 19;
  const subtotal   = itemsFactura.reduce((s,i) => s + i.subtotal, 0);
  const descTotal  = itemsFactura.reduce((s,i) => s + (i.cantidad * i.precio_unit * i.descuento/100), 0);
  const baseIva    = subtotal;
  const ivaValor   = baseIva * (ivaPct / 100);
  const total      = subtotal + ivaValor;

  const el = (id) => document.getElementById(id);
  if (el('fact-tot-subtotal'))   el('fact-tot-subtotal').textContent   = formatMoney(subtotal);
  if (el('fact-tot-descuento'))  el('fact-tot-descuento').textContent  = '- ' + formatMoney(descTotal);
  if (el('fact-tot-iva'))        el('fact-tot-iva').textContent        = formatMoney(ivaValor);
  if (el('fact-tot-iva-label'))  el('fact-tot-iva-label').textContent  = `IVA (${ivaPct}%)`;
  if (el('fact-tot-total'))      el('fact-tot-total').textContent      = formatMoney(total);
};

window.toggleMedioPago = function() {
  const forma = document.getElementById('fact-forma-pago').value;
  const vencEl = document.getElementById('fact-fecha-vencimiento');
  if (forma === 'credito') {
    vencEl.style.borderColor = 'var(--yellow)';
    if (!vencEl.value) {
      const d = new Date(); d.setDate(d.getDate() + 30);
      vencEl.value = d.toISOString().substring(0,10);
    }
  } else {
    vencEl.style.borderColor = '';
    vencEl.value = '';
  }
};

// ============================================================
//  GUARDAR FACTURA
// ============================================================
window.guardarFactura = function() {
  const msgEl = document.getElementById('fact-crear-msg');
  msgEl.style.display = 'none';

  const clienteId   = document.getElementById('fact-cliente-id').value;
  const clienteNom  = document.getElementById('fact-cliente-nombre').value;
  if (!clienteId || !clienteNom) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = '⚠ Selecciona un cliente antes de guardar la factura.';
    msgEl.style.display = 'block'; return;
  }
  if (!itemsFactura.length) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = '⚠ Agrega al menos un ítem a la factura.';
    msgEl.style.display = 'block'; return;
  }

  const numero     = document.getElementById('fact-numero').value;
  const fechaEmis  = document.getElementById('fact-fecha-emision').value;
  const fechaVenc  = document.getElementById('fact-fecha-vencimiento').value;
  const formaPago  = document.getElementById('fact-forma-pago').value;
  const medioPago  = document.getElementById('fact-medio-pago').value;
  const notas      = document.getElementById('fact-notas').value;
  ivaPct = parseFloat(document.getElementById('fact-iva').value) || 19;

  const nit       = DB.Config.get('nit') || '';
  const subtotal  = itemsFactura.reduce((s,i) => s + i.subtotal, 0);
  const ivaValor  = subtotal * (ivaPct/100);
  const total     = subtotal + ivaValor;
  const cufe      = generarCUFE(numero, fechaEmis, nit, total);

  // Insertar factura
  DB.dbRun(`INSERT INTO facturas
    (numero,cufe,cliente_id,cliente_nombre,cliente_nit,cliente_dir,cliente_email,cliente_tel,
     subtotal,descuento,iva_pct,iva_valor,total,forma_pago,medio_pago,estado,notas,
     fecha_emision,fecha_vencimiento)
    VALUES (?,?,?,?,?,?,?,?,?,0,?,?,?,?,?,'pendiente',?,?,?)`,
    [numero, cufe, clienteId, clienteNom,
     document.getElementById('fact-cliente-nit').value,
     document.getElementById('fact-cliente-dir').value,
     document.getElementById('fact-cliente-email').value,
     document.getElementById('fact-cliente-tel').value,
     subtotal, ivaPct, ivaValor, total, formaPago, medioPago, notas, fechaEmis, fechaVenc]
  );

  const facturaRow = DB.dbGet("SELECT id FROM facturas WHERE numero = ?", [numero]);
  const factId = facturaRow?.id;

  // Insertar ítems y descontar stock
  itemsFactura.forEach(item => {
    DB.dbRun(`INSERT INTO facturas_detalle
      (factura_id,producto_id,descripcion,cantidad,precio_unit,descuento,iva_pct,subtotal)
      VALUES (?,?,?,?,?,?,?,?)`,
      [factId, item.prodId, item.descripcion, item.cantidad,
       item.precio_unit, item.descuento, item.iva_pct, item.subtotal]
    );
    if (item.prodId) {
      const prod = DB.Productos.getById(parseInt(item.prodId));
      if (prod) {
        const antes = prod.stock;
        const despues = Math.max(0, antes - item.cantidad);
        DB.dbRun("UPDATE productos SET stock = ? WHERE id = ?", [despues, item.prodId]);
        DB.dbRun(`INSERT INTO movimientos
          (producto_id,tipo,cantidad,stock_antes,stock_despues,referencia,nota,usuario_id)
          VALUES (?,'salida',?,?,?,?,'Factura electrónica',1)`,
          [item.prodId, -item.cantidad, antes, despues, numero]
        );
      }
    }
  });

  DB.saveDB();
  itemsFactura = [];

  verFactura(factId);
  showToast('✓ Factura ' + numero + ' creada correctamente');
};

// ============================================================
//  VER FACTURA — PDF
// ============================================================
window.verFactura = function(id) {
  const f    = DB.dbGet("SELECT * FROM facturas WHERE id = ?", [id]);
  const det  = DB.dbQuery("SELECT * FROM facturas_detalle WHERE factura_id = ?", [id]);
  if (!f) return;

  const empresa = {
    razon:   DB.Config.get('razon_social') || DB.Config.get('nombre_empresa') || '',
    nit:     DB.Config.get('nit')           || '',
    dir:     DB.Config.get('direccion_empresa') || '',
    tel:     DB.Config.get('telefono_empresa')  || '',
    email:   DB.Config.get('email_empresa')     || '',
    regimen: DB.Config.get('regimen_fiscal')    || '',
  };

  const mediosPago = {
    efectivo:'Efectivo', transferencia:'Transferencia bancaria',
    tarjeta_credito:'Tarjeta de crédito', tarjeta_debito:'Tarjeta de débito',
    cheque:'Cheque', otro:'Otro'
  };

  const qrData = `FE:${f.numero}|NIT:${empresa.nit}|CUFE:${f.cufe}|TOTAL:${f.total}`;
  const qrUrl  = `https://api.qrserver.com/v1/create-qr-code/?size=90x90&data=${encodeURIComponent(qrData)}`;

  document.getElementById('factura-preview-body').innerHTML = `
    <div id="factura-imprimible" style="font-family:Arial,sans-serif;font-size:13px;
         color:#111;max-width:680px;margin:0 auto;border:1px solid #ddd;padding:28px">

      <!-- Encabezado -->
      <div style="text-align:center;border-bottom:3px solid #1E3A5F;padding-bottom:16px;margin-bottom:16px">
        <div style="font-size:11px;color:#888;letter-spacing:2px;margin-bottom:4px">DOCUMENTO EQUIVALENTE</div>
        <div style="font-size:22px;font-weight:bold;color:#1E3A5F;margin-bottom:2px">
          FACTURA ELECTRÓNICA DE VENTA
        </div>
        <div style="font-size:13px;color:#555">${empresa.regimen || ''}</div>
      </div>

      <!-- Emisor + QR -->
      <div style="display:flex;justify-content:space-between;margin-bottom:16px">
        <div style="flex:1">
          <div style="font-weight:bold;font-size:15px;color:#1E3A5F">${empresa.razon}</div>
          <div style="font-family:monospace;font-size:12px;color:#555">NIT: ${empresa.nit}</div>
          <div style="font-size:12px;color:#555">${empresa.dir}</div>
          <div style="font-size:12px;color:#555">${empresa.tel}${empresa.email?' | '+empresa.email:''}</div>
        </div>
        <div style="text-align:right">
          <img src="${qrUrl}" alt="QR" style="width:90px;height:90px;border:1px solid #eee"/>
          <div style="font-size:9px;color:#aaa;margin-top:2px">Código QR obligatorio</div>
        </div>
      </div>

      <!-- N° factura + fechas -->
      <div style="background:#f0f4fa;border-radius:4px;padding:12px;margin-bottom:16px;
                  display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
        <div>
          <div style="font-size:9px;color:#888;font-weight:bold;letter-spacing:1px">N° FACTURA</div>
          <div style="font-family:monospace;font-size:14px;font-weight:bold;color:#1E3A5F">${f.numero}</div>
        </div>
        <div>
          <div style="font-size:9px;color:#888;font-weight:bold;letter-spacing:1px">FECHA EMISIÓN</div>
          <div style="font-size:13px">${formatFecha(f.fecha_emision)}</div>
        </div>
        <div>
          <div style="font-size:9px;color:#888;font-weight:bold;letter-spacing:1px">FECHA VENCIMIENTO</div>
          <div style="font-size:13px">${f.fecha_vencimiento ? formatFecha(f.fecha_vencimiento) : 'Contado'}</div>
        </div>
      </div>

      <!-- Adquiriente -->
      <div style="border:1px solid #ddd;border-radius:4px;padding:12px;margin-bottom:16px">
        <div style="font-size:10px;color:#888;font-weight:bold;letter-spacing:1px;margin-bottom:6px">
          DATOS DEL ADQUIRIENTE
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px">
          <div><b>Nombre / Razón social:</b> ${f.cliente_nombre}</div>
          <div><b>NIT / Cédula:</b> <span style="font-family:monospace">${f.cliente_nit||'—'}</span></div>
          <div><b>Dirección:</b> ${f.cliente_dir||'—'}</div>
          <div><b>Email:</b> ${f.cliente_email||'—'}</div>
        </div>
      </div>

      <!-- Tabla de ítems -->
      <table style="width:100%;border-collapse:collapse;margin-bottom:16px">
        <thead>
          <tr style="background:#1E3A5F;color:#fff">
            <th style="padding:8px;text-align:left;font-size:11px">#</th>
            <th style="padding:8px;text-align:left;font-size:11px">DESCRIPCIÓN</th>
            <th style="padding:8px;text-align:center;font-size:11px">CANT.</th>
            <th style="padding:8px;text-align:right;font-size:11px">P.UNITARIO</th>
            <th style="padding:8px;text-align:right;font-size:11px">DESC.</th>
            <th style="padding:8px;text-align:right;font-size:11px">SUBTOTAL</th>
          </tr>
        </thead>
        <tbody>
          ${det.map((d,i) => `
            <tr style="background:${i%2===0?'#fff':'#f8fafc'}">
              <td style="padding:7px 8px;font-size:12px">${i+1}</td>
              <td style="padding:7px 8px;font-size:12px">${d.descripcion}</td>
              <td style="padding:7px 8px;text-align:center;font-family:monospace;font-size:12px">${d.cantidad}</td>
              <td style="padding:7px 8px;text-align:right;font-family:monospace;font-size:12px">${formatMoney(d.precio_unit)}</td>
              <td style="padding:7px 8px;text-align:right;font-size:12px">${d.descuento}%</td>
              <td style="padding:7px 8px;text-align:right;font-family:monospace;font-size:12px;font-weight:bold">${formatMoney(d.subtotal)}</td>
            </tr>`).join('')}
        </tbody>
      </table>

      <!-- Totales -->
      <div style="display:flex;justify-content:flex-end;margin-bottom:16px">
        <div style="width:280px">
          <div style="display:flex;justify-content:space-between;padding:5px 0;
                      border-bottom:1px solid #eee;font-size:13px">
            <span style="color:#555">Subtotal</span>
            <span style="font-family:monospace">${formatMoney(f.subtotal)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding:5px 0;
                      border-bottom:1px solid #eee;font-size:13px">
            <span style="color:#555">IVA (${f.iva_pct}%)</span>
            <span style="font-family:monospace">${formatMoney(f.iva_valor)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;padding:10px 0 0;font-size:17px;font-weight:bold">
            <span>TOTAL</span>
            <span style="font-family:monospace;color:#1E3A5F">${formatMoney(f.total)}</span>
          </div>
        </div>
      </div>

      <!-- Forma de pago -->
      <div style="background:#f0f4fa;border-radius:4px;padding:10px;margin-bottom:16px;
                  display:flex;gap:24px;font-size:12px">
        <div>
          <span style="color:#888;font-weight:bold">FORMA DE PAGO: </span>
          <span>${f.forma_pago==='contado'?'Contado':'Crédito'}</span>
        </div>
        <div>
          <span style="color:#888;font-weight:bold">MEDIO DE PAGO: </span>
          <span>${mediosPago[f.medio_pago]||f.medio_pago}</span>
        </div>
      </div>

      ${f.notas ? `
      <div style="border:1px dashed #ccc;border-radius:4px;padding:10px;margin-bottom:16px;font-size:12px;color:#555">
        <b>Notas:</b> ${f.notas}
      </div>` : ''}

      <!-- CUFE -->
      <div style="border-top:2px solid #1E3A5F;padding-top:12px;font-size:10px;color:#888">
        <div style="font-weight:bold;margin-bottom:4px;letter-spacing:1px">
          CUFE — CÓDIGO ÚNICO DE FACTURA ELECTRÓNICA
        </div>
        <div style="font-family:monospace;word-break:break-all;background:#f5f5f5;
                    padding:6px;border-radius:3px;font-size:10px">${f.cufe}</div>
        <div style="margin-top:8px;text-align:center;color:#aaa">
          Factura electrónica generada por SistemaGest · ${new Date().toLocaleString('es-CO')}
        </div>
      </div>
    </div>`;

  document.getElementById('modal-factura-preview').style.display = 'flex';
};

window.imprimirFacturaElectronica = function() {
  const contenido = document.getElementById('factura-imprimible');
  if (!contenido) return;
  const win = window.open('', '_blank', 'width=750,height=900');
  win.document.write(`<!DOCTYPE html><html><head>
    <meta charset="UTF-8"/><title>Factura Electrónica</title>
    <style>
      body{margin:20px;font-family:Arial,sans-serif}
      @media print{body{margin:0}button{display:none!important}}
    </style>
  </head><body>
    ${contenido.outerHTML}
    <br><div style="text-align:center">
      <button onclick="window.print()" style="padding:10px 24px;cursor:pointer;font-size:14px">
        🖨 Imprimir / Guardar PDF
      </button>
    </div>
  </body></html>`);
  win.document.close();
};

// ── Vista previa antes de guardar ──
window.previsualizarFactura = function() {
  if (!itemsFactura.length) { showToast('Agrega al menos un ítem'); return; }
  const clienteNom = document.getElementById('fact-cliente-nombre').value;
  if (!clienteNom) { showToast('Selecciona un cliente'); return; }
  showToast('Guardando vista previa...');
  guardarFactura();
};

// ── Marcar como pagada ──
window.marcarPagada = function(id) {
  if (!confirm('¿Marcar esta factura como pagada?')) return;
  DB.dbRun("UPDATE facturas SET estado = 'pagada' WHERE id = ?", [id]);
  DB.saveDB();
  renderListaFacturas();
  showToast('Factura marcada como pagada');
};

// ── Anular factura ──
window.anularFactura = function(id, numero) {
  if (!confirm(`¿Anular la factura ${numero}? El stock será restaurado.`)) return;
  const det = DB.dbQuery("SELECT * FROM facturas_detalle WHERE factura_id = ?", [id]);
  det.forEach(d => {
    if (d.producto_id) {
      const prod = DB.Productos.getById(d.producto_id);
      if (prod) {
        const antes = prod.stock;
        const despues = antes + d.cantidad;
        DB.dbRun("UPDATE productos SET stock = ? WHERE id = ?", [despues, d.producto_id]);
        DB.dbRun(`INSERT INTO movimientos
          (producto_id,tipo,cantidad,stock_antes,stock_despues,referencia,nota,usuario_id)
          VALUES (?,'entrada',?,?,?,?,'Factura anulada',1)`,
          [d.producto_id, d.cantidad, antes, despues, numero]
        );
      }
    }
  });
  DB.dbRun("UPDATE facturas SET estado = 'anulada' WHERE id = ?", [id]);
  DB.saveDB();
  renderListaFacturas();
  showToast('Factura anulada — stock restaurado');
};

window.volverBienvenida = function() {
  document.getElementById('fact-seccion-bienvenida').style.display = 'block';
  document.getElementById('fact-seccion-lista').style.display = 'none';
  document.getElementById('fact-seccion-crear').style.display = 'none';
  renderResumenCards();
};
