/**
 * database.js — Capa de base de datos con sql.js
 * 
 * sql.js es SQLite compilado a WebAssembly.
 * La BD vive en memoria y se persiste en localStorage.
 *
 * INSTRUCCIÓN DE INSTALACIÓN:
 * Descarga sql-wasm.js y sql-wasm.wasm desde:
 * https://github.com/sql-js/sql.js/releases
 * y ponlos en la carpeta /libs/
 */

const DB_KEY = 'sistemgest_db'; // clave en localStorage

let db = null; // instancia global de la BD

// ============================================================
//  SCHEMA SQL — Todas las tablas del sistema
// ============================================================
const SCHEMA = `

PRAGMA foreign_keys = ON;

-- Usuarios del sistema
CREATE TABLE IF NOT EXISTS usuarios (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre      TEXT    NOT NULL,
  email       TEXT    UNIQUE NOT NULL,
  password    TEXT    NOT NULL,
  rol         TEXT    NOT NULL DEFAULT 'empleado',  -- admin | empleado
  cedula      TEXT,
  telefono    TEXT,
  direccion   TEXT,
  activo      INTEGER NOT NULL DEFAULT 1,
  creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Agrega columnas si no existen (para BDs ya creadas)
CREATE TABLE IF NOT EXISTS _tmp_check (x);
DROP TABLE _tmp_check;

-- Productos / artículos en inventario
CREATE TABLE IF NOT EXISTS productos (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo        TEXT    UNIQUE NOT NULL,
  nombre        TEXT    NOT NULL,
  descripcion   TEXT,
  categoria     TEXT,
  precio_compra REAL    NOT NULL DEFAULT 0,
  precio_venta  REAL    NOT NULL DEFAULT 0,
  stock         INTEGER NOT NULL DEFAULT 0,
  stock_minimo  INTEGER NOT NULL DEFAULT 5,
  unidad        TEXT    NOT NULL DEFAULT 'unidad',
  activo        INTEGER NOT NULL DEFAULT 1,
  creado_en     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Clientes
CREATE TABLE IF NOT EXISTS clientes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre      TEXT    NOT NULL,
  email       TEXT,
  telefono    TEXT,
  direccion   TEXT,
  ruc_dni     TEXT,
  activo      INTEGER NOT NULL DEFAULT 1,
  creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Proveedores
CREATE TABLE IF NOT EXISTS proveedores (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre      TEXT    NOT NULL,
  email       TEXT,
  telefono    TEXT,
  direccion   TEXT,
  ruc         TEXT,
  contacto    TEXT,
  activo      INTEGER NOT NULL DEFAULT 1,
  creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Ventas (cabecera)
CREATE TABLE IF NOT EXISTS ventas (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  numero        TEXT    UNIQUE NOT NULL,
  cliente_id    INTEGER REFERENCES clientes(id),
  usuario_id    INTEGER REFERENCES usuarios(id),
  subtotal      REAL    NOT NULL DEFAULT 0,
  impuesto      REAL    NOT NULL DEFAULT 0,
  total         REAL    NOT NULL DEFAULT 0,
  estado        TEXT    NOT NULL DEFAULT 'completada',  -- completada | anulada | pendiente
  notas         TEXT,
  creado_en     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Detalle de ventas
CREATE TABLE IF NOT EXISTS ventas_detalle (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  venta_id      INTEGER NOT NULL REFERENCES ventas(id),
  producto_id   INTEGER NOT NULL REFERENCES productos(id),
  cantidad      INTEGER NOT NULL,
  precio_unit   REAL    NOT NULL,
  subtotal      REAL    NOT NULL
);

-- Compras (cabecera)
CREATE TABLE IF NOT EXISTS compras (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  numero        TEXT    UNIQUE NOT NULL,
  proveedor_id  INTEGER REFERENCES proveedores(id),
  usuario_id    INTEGER REFERENCES usuarios(id),
  subtotal      REAL    NOT NULL DEFAULT 0,
  impuesto      REAL    NOT NULL DEFAULT 0,
  total         REAL    NOT NULL DEFAULT 0,
  estado        TEXT    NOT NULL DEFAULT 'recibida',
  notas         TEXT,
  creado_en     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Detalle de compras
CREATE TABLE IF NOT EXISTS compras_detalle (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  compra_id     INTEGER NOT NULL REFERENCES compras(id),
  producto_id   INTEGER NOT NULL REFERENCES productos(id),
  cantidad      INTEGER NOT NULL,
  precio_unit   REAL    NOT NULL,
  subtotal      REAL    NOT NULL
);

-- Movimientos de inventario (trazabilidad)
CREATE TABLE IF NOT EXISTS movimientos (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  producto_id   INTEGER NOT NULL REFERENCES productos(id),
  tipo          TEXT    NOT NULL,  -- entrada | salida | ajuste
  cantidad      INTEGER NOT NULL,
  stock_antes   INTEGER NOT NULL,
  stock_despues INTEGER NOT NULL,
  referencia    TEXT,              -- ej: "VENTA-001"
  nota          TEXT,
  usuario_id    INTEGER REFERENCES usuarios(id),
  creado_en     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Notificaciones del sistema
CREATE TABLE IF NOT EXISTS notificaciones (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo        TEXT    NOT NULL,   -- alerta | info | error | exito
  titulo      TEXT    NOT NULL,
  mensaje     TEXT    NOT NULL,
  leida       INTEGER NOT NULL DEFAULT 0,
  creado_en   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Configuración clave-valor
CREATE TABLE IF NOT EXISTS configuracion (
  clave       TEXT    PRIMARY KEY,
  valor       TEXT    NOT NULL,
  descripcion TEXT,
  actualizado_en TEXT DEFAULT (datetime('now'))
);

-- Datos iniciales de configuración
INSERT OR IGNORE INTO configuracion (clave, valor, descripcion) VALUES
  ('nombre_empresa',  'Mi Empresa S.A.',     'Nombre del negocio'),
  ('moneda',          'USD',                  'Moneda principal'),
  ('impuesto_pct',    '18',                   'Porcentaje de impuesto'),
  ('stock_minimo',    '5',                    'Stock mínimo por defecto'),
  ('version_db',      '1.0',                  'Versión del esquema');

-- Usuario administrador por defecto
INSERT OR IGNORE INTO usuarios (nombre, email, password, rol) VALUES
  ('Administrador', 'admin@sistema.com', 'admin123', 'admin');
`;

// ============================================================
//  Inicialización
// ============================================================
async function initDB() {
  try {
    // Carga sql.js desde el archivo local
    const SQL = await initSqlJs({
      locateFile: file => `libs/${file}`
    });

    // Intenta restaurar BD desde localStorage
    const saved = localStorage.getItem(DB_KEY);
    if (saved) {
      const uint8 = new Uint8Array(JSON.parse(saved));
      db = new SQL.Database(uint8);
      console.log('✅ BD restaurada desde localStorage');
    } else {
      db = new SQL.Database();
      console.log('✅ BD nueva creada en memoria');
    }

    // Aplica el schema
    db.run(SCHEMA);

    // Migración: agrega columnas nuevas si no existen en la BD actual
    try { db.run("ALTER TABLE usuarios ADD COLUMN cedula TEXT"); }    catch(e) {}
    try { db.run("ALTER TABLE usuarios ADD COLUMN telefono TEXT"); }  catch(e) {}
    try { db.run("ALTER TABLE usuarios ADD COLUMN direccion TEXT"); } catch(e) {}

    // Guarda la BD después de inicializar
    saveDB();

    setDBStatus('online', 'BD activa');
    return true;
  } catch (err) {
    console.error('❌ Error al inicializar BD:', err);
    setDBStatus('error', 'Error en BD');
    return false;
  }
}

// Persiste la BD en localStorage
function saveDB() {
  if (!db) return;
  try {
    const data = Array.from(db.export());
    localStorage.setItem(DB_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn('No se pudo guardar BD:', e);
  }
}

// Actualiza el indicador visual de estado
function setDBStatus(state, text) {
  const dot  = document.querySelector('.status-dot');
  const span = document.getElementById('db-status-text');
  if (dot)  { dot.className = `status-dot ${state}`; }
  if (span) { span.textContent = text; }
}

// ============================================================
//  CRUD GENÉRICO
// ============================================================

/** Ejecuta una consulta SELECT y retorna array de objetos */
function dbQuery(sql, params = []) {
  if (!db) throw new Error('BD no inicializada');
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) {
      rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows;
  } catch (err) {
    console.error('dbQuery error:', err.message, '\nSQL:', sql);
    throw err;
  }
}

/** Ejecuta INSERT / UPDATE / DELETE y guarda la BD */
function dbRun(sql, params = []) {
  if (!db) throw new Error('BD no inicializada');
  try {
    db.run(sql, params);
    saveDB();
    return { changes: db.getRowsModified(), lastId: dbQuery('SELECT last_insert_rowid() as id')[0]?.id };
  } catch (err) {
    console.error('dbRun error:', err.message, '\nSQL:', sql);
    throw err;
  }
}

/** Retorna un solo registro o null */
function dbGet(sql, params = []) {
  const rows = dbQuery(sql, params);
  return rows[0] || null;
}

// ============================================================
//  HELPERS POR MÓDULO
// ============================================================

const Productos = {
  getAll:    ()  => dbQuery('SELECT * FROM productos WHERE activo = 1 ORDER BY nombre'),
  getById:   (id)=> dbGet('SELECT * FROM productos WHERE id = ?', [id]),
  getByCod:  (c) => dbGet('SELECT * FROM productos WHERE codigo = ?', [c]),
  getLowStock: () => dbQuery('SELECT * FROM productos WHERE stock <= stock_minimo AND activo = 1'),
  create: (p) => dbRun(
    'INSERT INTO productos (codigo,nombre,descripcion,categoria,precio_compra,precio_venta,stock,stock_minimo,unidad) VALUES (?,?,?,?,?,?,?,?,?)',
    [p.codigo, p.nombre, p.descripcion||'', p.categoria||'', p.precio_compra, p.precio_venta, p.stock||0, p.stock_minimo||5, p.unidad||'unidad']
  ),
  update: (id, p) => dbRun(
    'UPDATE productos SET nombre=?, descripcion=?, categoria=?, precio_compra=?, precio_venta=?, stock_minimo=?, unidad=? WHERE id=?',
    [p.nombre, p.descripcion, p.categoria, p.precio_compra, p.precio_venta, p.stock_minimo, p.unidad, id]
  ),
  delete: (id) => dbRun('UPDATE productos SET activo = 0 WHERE id = ?', [id]),
};

const Clientes = {
  getAll:  ()   => dbQuery('SELECT * FROM clientes WHERE activo = 1 ORDER BY nombre'),
  getById: (id) => dbGet('SELECT * FROM clientes WHERE id = ?', [id]),
  create:  (c)  => dbRun(
    'INSERT INTO clientes (nombre, email, telefono, direccion, ruc_dni) VALUES (?,?,?,?,?)',
    [c.nombre, c.email||'', c.telefono||'', c.direccion||'', c.ruc_dni||'']
  ),
  update:  (id, c) => dbRun(
    'UPDATE clientes SET nombre=?, email=?, telefono=?, direccion=?, ruc_dni=? WHERE id=?',
    [c.nombre, c.email, c.telefono, c.direccion, c.ruc_dni, id]
  ),
  delete:  (id) => dbRun('UPDATE clientes SET activo = 0 WHERE id = ?', [id]),
};

const Proveedores = {
  getAll:  ()   => dbQuery('SELECT * FROM proveedores WHERE activo = 1 ORDER BY nombre'),
  getById: (id) => dbGet('SELECT * FROM proveedores WHERE id = ?', [id]),
  create:  (p)  => dbRun(
    'INSERT INTO proveedores (nombre, email, telefono, direccion, ruc, contacto) VALUES (?,?,?,?,?,?)',
    [p.nombre, p.email||'', p.telefono||'', p.direccion||'', p.ruc||'', p.contacto||'']
  ),
  delete:  (id) => dbRun('UPDATE proveedores SET activo = 0 WHERE id = ?', [id]),
};

const Notificaciones = {
  getAll:    ()   => dbQuery('SELECT * FROM notificaciones ORDER BY creado_en DESC LIMIT 50'),
  getUnread: ()   => dbQuery('SELECT * FROM notificaciones WHERE leida = 0 ORDER BY creado_en DESC'),
  countUnread: () => dbGet('SELECT COUNT(*) as n FROM notificaciones WHERE leida = 0')?.n || 0,
  create: (tipo, titulo, mensaje) => dbRun(
    'INSERT INTO notificaciones (tipo, titulo, mensaje) VALUES (?,?,?)',
    [tipo, titulo, mensaje]
  ),
  markRead: (id) => dbRun('UPDATE notificaciones SET leida = 1 WHERE id = ?', [id]),
  markAllRead: () => dbRun('UPDATE notificaciones SET leida = 1'),
};

const Config = {
  get:    (k)    => dbGet('SELECT valor FROM configuracion WHERE clave = ?', [k])?.valor,
  set:    (k, v) => dbRun('UPDATE configuracion SET valor = ?, actualizado_en = datetime(\'now\') WHERE clave = ?', [v, k]),
  getAll: ()     => dbQuery('SELECT * FROM configuracion'),
};

// Exponer globalmente
window.DB = { initDB, dbQuery, dbRun, dbGet, saveDB, Productos, Clientes, Proveedores, Notificaciones, Config };
